<?php
  if (!isset($_PHPkernel_cookie_)) {
    global $_PHPkernel_cookie_; $_PHPkernel_cookie_ = 1;

    require('PHPkernel.php');

    // We can set strings or arrays (of arrays(...)) of strings in a cookie.
    // Cookies are UTF-encoded when set and decoded when gotten.
    // This is a bit tricky when setting and getting arrays.

    function get_cookie_var($var_name, $default=null) {
      global $HTTP_COOKIE_VARS;
      if (isset($_COOKIE[$var_name]))              return utf_decode($_COOKIE[$var_name]);
      elseif (isset($HTTP_COOKIE_VARS[$var_name])) return utf_decode($HTTP_COOKIE_VARS[$var_name]);
      else                                         return $default;
    }

    function set_cookie_var($var_name, $value) {
      // in an array we set them one by one.
      if (is_array($value)) {
        $result = true;
        foreach ($value as $index => $part)
          $result = $result && set_cookie_var($var_name.'['.$index.']', $part);
      } else {
        $result = setcookie($var_name, utf_encode($value), time()+(60*60*24*365));
      }
      return $result;
    }

    function is_cookie_var($var_name) {
      global $HTTP_COOKIE_VARS;
      return (isset($_COOKIE[$var_name]) || isset($HTTP_COOKIE_VARS[$var_name]));
    }

    function unset_cookie_var($var_name) {
      global $HTTP_COOKIE_VARS;

      if (isset($_COOKIE[$var_name]))              $temp = $_COOKIE[$var_name];
      elseif (isset($HTTP_COOKIE_VARS[$var_name])) $temp = $HTTP_COOKIE_VARS[$var_name];
      else                                         return false;

      // in an array we unset them one by one.
      if (is_array($temp)) {
        $result = true;
        foreach ($temp as $index => $part)
          $result = $result && unset_cookie_var($var_name.'['.$index.']', $part);
      } else {
        $result = setcookie($var_name, '', time()-(60*60*24*365));
      }
      return $result;
    }
  }
?>