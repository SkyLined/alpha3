<?php
  if (!isset($_PHPkernel_session_)) {
    global $_PHPkernel_session_; $_PHPkernel_session_ = 1;

    require('PHPkernel.php');

    function start_session() {
      session_start();
      if (is_session_var("_PHPkernel_session_")) return false;
      else set_session_var("_PHPkernel_session_");
      return true;
    }

    function get_session_var($var_name, $default) {
      global $HTTP_SESSION_VARS;
      if (isset($_SESSION[$var_name]))              return unserialize($_SESSION[$var_name]);
      elseif (isset($HTTP_SESSION_VARS[$var_name])) return unserialize($HTTP_SESSION_VARS[$var_name]);
      else                                          return $default;
    }

    function set_session_var($var_name, $value=1) {
      global $HTTP_SESSION_VARS;
      if (isset($_SESSION)) {
        $_SESSION[$var_name] = serialize($value);
        return true;
      } elseif (isset($HTTP_SESSION_VARS)) {
        $HTTP_SESSION_VARS[$var_name] = serialize($value);
        return true;
      } else {
        return false;
      }
    }

    function is_session_var($var_name) {
      global $HTTP_SESSION_VARS;
      return (isset($_SESSION[$var_name]) || isset($HTTP_SESSION_VARS[$var_name]));
    }

  }
?>