<?php
  if (!isset($_PHPkernel_redirect_)) {
    global $_PHPkernel_redirect_; $_PHPkernel_redirect_ = 1;
    
    require('PHPkernel.php');
    
    function redirect($url) {
      header('Location: '.$url);
    }
    function reload() {
      header('Location: http://'.$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI']);
    }
  }
?>