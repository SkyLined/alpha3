<?php
  if (!isset($_PHPkernel_getpost_)) {
    global $_PHPkernel_getpost_; $_PHPkernel_getpost_ = 1;

    require('PHPkernel.php');

    function get_post_var($var_name, $default=null) {
      global $HTTP_POST_VARS;
      if (isset($_POST[$var_name]))                return $_POST[$var_name];
      elseif (isset($HTTP_POST_VARS[$var_name]))   return $HTTP_POST_VARS[$var_name];
      else                                         return $default;
    }
    function is_post_var($var_name) {
      global $HTTP_POST_VARS;
      if (isset($_POST[$var_name]))                return true;
      elseif (isset($HTTP_POST_VARS[$var_name]))   return true;
      else                                         return false;
    }

    function get_get_var($var_name, $default=null) {
      global $HTTP_GET_VARS;
      if (isset($_GET[$var_name]))                 return utf_decode($_GET[$var_name]);
      elseif (isset($HTTP_GET_VARS[$var_name]))    return utf_decode($HTTP_GET_VARS[$var_name]);
      else                                         return $default;
    }
    function is_get_var($var_name) {
      global $HTTP_GET_VARS;
      if (isset($_GET[$var_name]))                 return true;
      elseif (isset($HTTP_GET_VARS[$var_name]))    return true;
      else                                         return false;
    }
  }
?>