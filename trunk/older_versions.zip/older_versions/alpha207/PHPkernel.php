<?php
  if (!isset($_PHPkernel_)) {
    global $_PHPkernel_; $_PHPkernel_ = 1;

    require('PHPkernel.getpost.php');
    require('PHPkernel.cookie.php');
    require('PHPkernel.session.php');
    require('PHPkernel.redirect.php');
    require('PHPkernel.upload.php');

    // utf-decode encodes strings with the %XX (UTF) encoding
    // (space = %20, '%' = %25, etc...)
    function utf_encode($var) {
      return rawurlencode($var);
    }
    // utf-decode decodes strings OR ARRAYS (OF ARRAYS(OF ARRAYS(...))) OF STRINGS
    function utf_decode($var) {
      if (is_array($var)) {
        foreach ($var as $index => $value) $var[$index] = utf_decode($value);
      } else {
        $var = rawurldecode($var);
      }
      return $var;
    }
  }
?>