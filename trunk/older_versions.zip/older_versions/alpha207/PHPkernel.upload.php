<?php
  if (!isset($_PHPkernel_upload_)) {
    global $_PHPkernel_upload_; $_PHPkernel_upload_ = 1;

    require('PHPkernel.php');

    function get_upload_filename() {
      global $HTTP_POST_FILES;
      if (isset($_FILES['userfile']['name']))       return $_FILES['userfile']['name'];
      elseif (isset($HTTP_POST_FILES['userfile']['name'])) return $HTTP_POST_FILES['userfile']['name'];
      else                                          return null;
    }

    function get_upload_filesize() {
      global $HTTP_POST_FILES;
      if (isset($_FILES['userfile']['size']))       return $_FILES['userfile']['size'];
      elseif (isset($HTTP_POST_FILES['userfile']['size'])) return $HTTP_POST_FILES['userfile']['size'];
      else                                          return 0;
    }

    function get_upload_filepath() {
      global $HTTP_POST_FILES;
      if (isset($_FILES['userfile']['tmp_name']))       return $_FILES['userfile']['tmp_name'];
      elseif (isset($HTTP_POST_FILES['userfile']['tmp_name'])) return $HTTP_POST_FILES['userfile']['tmp_name'];
      else                                          return null;
    }

    function is_upload_file() {
      return is_uploaded_file(get_upload_file());
    }

  }
?>