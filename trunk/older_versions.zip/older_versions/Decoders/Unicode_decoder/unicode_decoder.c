#define A "    add    %al, 0(%ecx)          \n"

int main(void) {
  __asm__(
    // output the code to stdout
    "   mov     $end-start, %edx      \n" // length
    "   mov     $start, %ecx          \n" // source
    "   mov     $0x1, %ebx            \n" // stdout
    "   mov     $0x4, %eax            \n" // write
    "   int     $0x80                 \n"
    "   jmp     end                   \n"
    "start:                           \n"
    
    "    .set   var1, 0x31000000+(l2-start-1)*0x100 \n"
    "    .set   var2, 0x71000000+((l1-l2)&0xff)*0x100 \n"
    "    mov    $var1, %eax           \n"
A
    "    push   %ecx                  \n"
A
    "    push   %esp                  \n"
A
    "    pop    %ebx                  \n"
    "    add    %ah, 0(%ebx)          \n"
    "    pop    %esi                  \n"
A
    "    xor    $var2^var1, %eax      \n"
    "    add    %ah, 0(%esi)          \n"
    "    inc    %esi                  \n"
A
    "    push   %esi                  \n"
A
    "    pop    %edi                  \n"
A
    "l1: movsb                        \n"
A
    "    inc    %esi                  \n"
    "    add    %al, 0(%esi)          \n"
    "    jne    l2                    \n"
    "l2:                              \n"
    "end:                             \n"
  );
  exit(0);
}
