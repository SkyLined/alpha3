<?php
  // usefull function wrappers ------------------------------------------------
  
  function post_var($var_name, $default) {
    global $HTTP_POST_VARS;
    if (isset($_POST[$var_name]))                return stripslashes(rawurldecode($_POST[$var_name]));
    elseif (isset($HTTP_POST_VARS[$var_name]))   return stripslashes(rawurldecode($HTTP_POST_VARS[$var_name]));
    else                                         return $default;
  }
  
  // set up some statics ------------------------------------------------------

  $version = "ALPHA (build 06-php)";
  $copyright = "Copyright (C) 2003, 2004 by Berend-Jan Wever.";
  $banner =
    "<HR>\n".
    "<B>&nbsp;&nbsp;&nbsp;&nbsp;,sSSs,,s,&nbsp;&nbsp;</B>$version<BR>\n".
    "<B>&nbsp;&nbsp;&nbsp;SS&quot;&nbsp;&nbsp;Y\$P&quot;</B><BR>\n".
    "<B>&nbsp;&nbsp;iS'&nbsp;&nbsp;&nbsp;dY&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</B>Uppercase, alphanumeric shellcode encoding.<BR>\n".
    "<B>&nbsp;&nbsp;YS,&nbsp;&nbsp;dSb&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</B>$copyright<BR>\n".
    "<B>&nbsp;&nbsp;`&quot;YSS'&quot;S'&nbsp;&nbsp;&nbsp;&nbsp;</B>&lt;<A href=\"mailto:skylined@edup.tudelft.nl\">skylined@edup.tudelft.nl</A>&gt;<BR>\n".
    "<HR>\n";
  $ack = 
    "Acknowledgements:<BR>\n".
    "Thanks to rix for his phrack article on aphanumeric shellcode.<BR>\n".
    "Thanks to Costin Ionescu for the idear behind w32 SEH GetPC code.<BR>\n".
    "Thanks to 0dd for help, information and feedback.<BR>\n";

  $alpha_decoder_main_code1 = "VTX630VX4A0B5HH0B20BBVX2BCBH4A2AC0ACTBCQB0ACAVX4Z8BCJOM";
  $alpha_decoder_main_code2 = "VTX630VX4A0B4HH0B10BAVX2BBBH4A2AB0ABTBBQB0ABAVX4Z8BBJOM";
  $options = array();
  $options["eax"] = "PZJJJJJRY".$alpha_decoder_main_code1;
  $options["ecx"] = "IIIIIIQZ".$alpha_decoder_main_code1;
  $options["edx"] = "JJJJJJRY".$alpha_decoder_main_code1;
  $options["ebx"] = "SZJJJJJRY".$alpha_decoder_main_code1;
  $options["esp"] = "TZJJJJJRY".$alpha_decoder_main_code1;
  $options["ebp"] = "UZJJJJJRY".$alpha_decoder_main_code1;
  $options["esi"] = "VZJJJJJRY".$alpha_decoder_main_code1;
  $options["edi"] = "WZJJJJJRY".$alpha_decoder_main_code1;
  $options["[esp-8]"] = "ZZZJJJJRY".$alpha_decoder_main_code2;
  $options["[esp-4]"] = "ZZJJJJJRY".$alpha_decoder_main_code1;
  $options["[esp]"] = "ZJJJJJRY".$alpha_decoder_main_code2;
  $options["[esp+4]"] = "LLLLZJJJRY".$alpha_decoder_main_code2;
  $options["[esp+8]"] = "LLLLLLLLZJRY".$alpha_decoder_main_code2;
  $options["seh"] = "VTX630WTX638VXH49HHHPVX5AAQQPVX5YYYYP5YYYD5KKYAPTTX638TDDNVDDX4Z4A63861816IIIIIIQZ".$alpha_decoder_main_code1;
  
  // main code ----------------------------------------------------------------
  
  $help = post_var("help", false);
  $encode = post_var("encode", false);
  $option = post_var("option", false);
  $shellcode = post_var("shellcode", false);
  
  if ($encode && !$shellcode) {
    $shellcode = "Please supply a shellcode here, n00b!";
    $encode = false;
  }
  if ($encode && $option && $shellcode) {
    if (!$options[$option]) {
      $result = "Option unknown.";
    } else {
      $result = $options[$option];
      for ($i=0; $i < strlen($shellcode); $i++) {
        $input = ord($shellcode{$i});
        $lownibble = ($input & 0x0f);
        $highnibble = ($input & 0xf0) >> 4;
        $lownibble_encoded  = ($lownibble ^ 0x41) + 1;
        $highnibble_encoded = ($highnibble == 0x0 ? 0x50 : $highnibble+0x40);
        $result .= chr($lownibble_encoded).chr($highnibble_encoded);
      }
      $result .= "Z";
    }
  }
?><HTML>
  <HEAD>
    <TITLE><?php echo $version ?></TITLE>
    <STYLE>
      * {
        font: 10pt courier new, courier;
        color: #00C000;
        background-color: black;
        scrollbar-3dlight-color: limegreen;
        scrollbar-arrow-color: ;
        scrollbar-base-color: ;
        scrollbar-darkshadow-color: ;
        scrollbar-face-color: green;
        scrollbar-highlight-color: limegreen;
        scrollbar-shadow-color: darkgreen;
      }
      :link {
        color: #00FF00;
        text-decoration: none;
      }
      :visited {
        color: #00E000;
        text-decoration: none;
      }
      :hover {
        color: #00FF00;
        text-decoration: underline!important;
      }
      :active {
        color: #000000;
        background-color: #008000;
        text-decoration: none;
      }
      BODY {
        padding: 20px;
      }
      B {
        font-weight: bold;
      }
      SELECT, TEXTAREA, .inset {
        border-top: 2px solid #008000;
        border-left: 3px solid #008000;
        border-bottom: 2px solid #00D000;
        border-right: 3px solid #00D000;
        background-color: #002800;
      }
      .outset {
        border-top: 2px solid #00D000;
        border-left: 3px solid #00D000;
        border-bottom: 2px solid #008000;
        border-right: 3px solid #008000;
        background-color: #002800;
      }
    </STYLE>
  </HEAD>
  <BODY>
    <?php echo $banner ?>
    <BR>
    <FORM method="post" name="f">
      <?php if ($help) { ?>
        <B>ALPHA</B> encodes shellcode to contain only uppercase alphanumeric
        characters (0-9 and A-Z). The output consists of a decoder and the
        encoded origional shellcode. This is a fully working version of the
        origional shellcode.<BR>
        The decoder will patch it's own code to create a small loop. This loop
        will decode the encoded shellcode untill it reaches a 'Z' character.
        It then transfers execution to the now decoded shellcode, conveniently
        passing the base-address of that code in register ecx.<BR>
        <BR>
        ALPHA encoded shellcode only works on <B>IA-32 (x86)</B> machines.<BR>
        <BR>
        The decoder needs to know it's own <B>baseaddress</B>, so you must
        choose a source. This can be any of the following:<BR>
        - Registers: eax, ebx, ecx, edx, esi, edi, esp and ebp.<BR>
        - Stack locations: [esp-8], [esp-4], [esp], [esp+4] and [esp+8].<BR>
        - Win32 SEH GetPC code (winNT/2K/XP only)<BR>
        <BR>
        <B>Win32 SEH GetPC</B> Will calculate the baseaddress of your shellcode.
        This is usefull when no register or memory pointer seems to point to your
        shellcode. It hooks a new SEH handler and causes an exception. The new
        SEH can determine the location where the exception took place. It then
        skips the offending instruction and transfers execution back to the code.
        This requires a win32 opperating system and an executable stack. This
        will not work if the exploited thread has used more then 65535 bytes of
        stack or if one of the exploited programs exception handlers catches
        write exceptions before our SEH does.<BR>
        <BR>
        <INPUT type="hidden" name="option"<?php if ($option) echo " value=\"".htmlspecialchars($option)."\""; ?>>
        <INPUT type="hidden" name="shellcode"<?php if ($shellcode) echo " value=\"".htmlspecialchars($shellcode)."\""; ?>>
        <INPUT class="outset" type="submit" value="<-- Click here to go back."><BR>
      <?php } else if ($encode) { ?>
        Encoded shellcode:<BR>
        <INPUT type="hidden" name="option"<?php if ($option) echo " value=\"".htmlspecialchars($option)."\""; ?>>
        <INPUT type="hidden" name="shellcode"<?php if ($shellcode) echo " value=\"".htmlspecialchars($shellcode)."\""; ?>>
        <TEXTAREA style="width:100%; height: 15em;"><?php echo htmlspecialchars($result); ?></TEXTAREA><BR>
        <BR>
        <INPUT class="outset" type="submit" value="<-- Click here to go back."><BR>
      <?php } else { ?>
        Choose your baseaddress source:
        <SELECT class="inset" name="option"><?php
          foreach ($options as $key => $value)
            if ($option == $key)
              echo "<OPTION selected>".$key."</OPTION>";
            else
              echo "<OPTION>".$key."</OPTION>";
        ?></SELECT><BR>
        Paste shellcode here:<BR>
        <TEXTAREA style="width:100%; height: 15em;" name="shellcode"><?php if ($shellcode) echo htmlspecialchars($shellcode); ?></TEXTAREA><BR>
        <BR>
        <INPUT class="outset" type="submit" name="encode" value="Click here to encode -->"><BR>
        <BR>
        <INPUT class="outset" type="submit" name="help" value="WTF!? I'd like to RTFM, please..."><BR>
      <?php } ?>
    </FORM>
    <BR>
    <HR>
    <?php echo $ack ?>
  </BODY>
</HTML>
